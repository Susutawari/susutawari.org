library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity COMPM2_VHDL is

    port (
        A  : in std_logic_vector(1 downto 0);
        B  : in std_logic_vector(1 downto 0);
        GT : out std_logic;
        LT : out std_logic);

end COMPM2_VHDL;

architecture RTL of COMPM2_VHDL is

begin

    GT <= '1' when A > B else '0';
    LT <= '1' when A < B else '0';

end RTL;
