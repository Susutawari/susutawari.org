library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity PWM_Ctrl_rev_VHDL is

    port (
        CLK   : in  std_logic;
        SW    : in  std_logic_vector(7 downto 0);
        PSW0  : in  std_logic;
        MD1   : out std_logic;
        MD2   : out std_logic;
        LED0  : out std_logic);

end PWM_Ctrl_rev_VHDL;

architecture RTL of PWM_Ctrl_rev_VHDL is

    signal sw_reg_1d    : std_logic_vector(7 downto 0);
    signal sw_reg_2d    : std_logic_vector(7 downto 0);
    signal pwm_base_reg : std_logic_vector(10 downto 0);
    signal pwm_duty_reg : std_logic_vector(10 downto 0);
    signal psw0_reg     : std_logic;
    signal psw0_cnt_reg : std_logic_vector(23 downto 0);
    signal dir          : std_logic;
    signal pwm_out      : std_logic;
    signal pwm_out_reg  : std_logic;
    signal pwmbp        : std_logic;
    signal tout         : std_logic;

-- Switch Input
begin

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          sw_reg_1d <= SW;
          sw_reg_2d <= sw_reg_1d;
        end if;
    end process;

-- PWM Base Cycle Generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (pwmbp = '1') then
            pwm_base_reg <= "00000000000";
          else
            pwm_base_reg <= pwm_base_reg + '1';
          end if;
        end if;
    end process;

    pwmbp <= pwm_base_reg(10);

-- PWM Duty Ratio Generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (pwmbp = '1') then
            pwm_duty_reg <= "00000000000";
          elsif (pwm_out = '1') then
            pwm_duty_reg <= pwm_duty_reg + '1';
          end if;
        end if;
    end process;

    pwm_out <= '0' when pwm_duty_reg(10 downto 3) = sw_reg_2d else '1';

-- To a motor driver
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          pwm_out_reg <= pwm_out;
        end if;
    end process;

-- Stop 0.3s and Toggle switch
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (tout = '1') then
            psw0_reg <= '0';
          elsif (PSW0 = '1') then
            psw0_reg <= '1';
          end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (tout = '1') then
            psw0_cnt_reg <= X"000000";
          elsif (psw0_reg = '1') then
            psw0_cnt_reg <= psw0_cnt_reg + '1';
          end if;
        end if;
    end process;

    tout <= psw0_cnt_reg(0) and psw0_cnt_reg(1) and psw0_cnt_reg(2) and psw0_cnt_reg(3)
            and psw0_cnt_reg(4) and psw0_cnt_reg(5) and psw0_cnt_reg(6) and psw0_cnt_reg(7)
            and psw0_cnt_reg(8) and psw0_cnt_reg(9) and psw0_cnt_reg(10) and psw0_cnt_reg(11)
            and psw0_cnt_reg(12) and psw0_cnt_reg(13) and psw0_cnt_reg(14) and psw0_cnt_reg(15)
            and psw0_cnt_reg(16) and psw0_cnt_reg(17) and psw0_cnt_reg(18) and psw0_cnt_reg(19)
            and psw0_cnt_reg(20) and psw0_cnt_reg(21) and psw0_cnt_reg(22) and psw0_cnt_reg(23)
            and psw0_reg;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (tout = '1') then
            dir <= not dir;
          end if;
        end if;
    end process;

    MD1 <= not (pwm_out_reg and dir) and not psw0_reg;
    MD2 <= not (pwm_out_reg and not dir) and not psw0_reg;
    LED0 <= dir;

end RTL;
