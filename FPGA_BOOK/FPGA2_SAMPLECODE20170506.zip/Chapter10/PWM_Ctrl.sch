<?xml version="1.0" encoding="UTF-8"?>
<drawing version="7">
    <attr value="spartan3e" name="DeviceFamilyName">
        <trait delete="all:0" />
        <trait editname="all:0" />
        <trait edittrait="all:0" />
    </attr>
    <netlist>
        <signal name="XLXN_12" />
        <signal name="PWM_BASE(15:0)" />
        <signal name="CLK" />
        <signal name="XLXN_10" />
        <signal name="XLXN_15(7:0)" />
        <signal name="PWM_DUTY(15:0)" />
        <signal name="PWM_DUTY(10:3)" />
        <signal name="XLXN_58(7:0)" />
        <signal name="XLXN_77" />
        <signal name="SW(7:0)" />
        <signal name="XLXN_74(7:0)" />
        <signal name="XLXN_75" />
        <signal name="XLXN_76" />
        <signal name="XLXN_102" />
        <signal name="XLXN_103" />
        <signal name="PWMOUT" />
        <signal name="MD1" />
        <signal name="XLXN_106" />
        <signal name="XLXN_107" />
        <signal name="MD2" />
        <signal name="PWM_BASE(10)" />
        <signal name="PWMBP" />
        <port polarity="Input" name="CLK" />
        <port polarity="Input" name="SW(7:0)" />
        <port polarity="Output" name="MD1" />
        <port polarity="Output" name="MD2" />
        <blockdef name="cb16re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="320" y1="-128" y2="-128" x1="384" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="320" y1="-192" y2="-192" x1="384" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="ibufg">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
        </blockdef>
        <blockdef name="vcc">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-64" x1="64" />
            <line x2="64" y1="0" y2="-32" x1="64" />
            <line x2="32" y1="-64" y2="-64" x1="96" />
        </blockdef>
        <blockdef name="comp8">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="256" x="64" y="-384" height="320" />
            <line x2="320" y1="-224" y2="-224" x1="384" />
            <rect width="64" x="0" y="-332" height="24" />
            <line x2="64" y1="-320" y2="-320" x1="0" />
            <rect width="64" x="0" y="-140" height="24" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
        </blockdef>
        <blockdef name="fd8re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <rect width="64" x="0" y="-268" height="24" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="inv">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="160" y1="-32" y2="-32" x1="224" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="64" y1="0" y2="-64" x1="64" />
            <circle r="16" cx="144" cy="-32" />
        </blockdef>
        <blockdef name="ibuf8">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="96" x="128" y="-44" height="24" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <rect width="64" x="0" y="-44" height="24" />
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
        </blockdef>
        <blockdef name="gnd">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-96" x1="64" />
            <line x2="52" y1="-48" y2="-48" x1="76" />
            <line x2="60" y1="-32" y2="-32" x1="68" />
            <line x2="40" y1="-64" y2="-64" x1="88" />
            <line x2="64" y1="-64" y2="-80" x1="64" />
            <line x2="64" y1="-128" y2="-96" x1="64" />
        </blockdef>
        <blockdef name="fd">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="256" x="64" y="-320" height="256" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
        </blockdef>
        <blockdef name="obuf">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
        </blockdef>
        <blockdef name="buf">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <line x2="128" y1="0" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-64" x1="128" />
            <line x2="64" y1="-64" y2="0" x1="64" />
        </blockdef>
        <block symbolname="cb16re" name="XLXI_1">
            <blockpin signalname="XLXN_12" name="C" />
            <blockpin signalname="XLXN_10" name="CE" />
            <blockpin signalname="PWMBP" name="R" />
            <blockpin name="CEO" />
            <blockpin signalname="PWM_BASE(15:0)" name="Q(15:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="ibufg" name="XLXI_5">
            <blockpin signalname="CLK" name="I" />
            <blockpin signalname="XLXN_12" name="O" />
        </block>
        <block symbolname="vcc" name="XLXI_6">
            <blockpin signalname="XLXN_10" name="P" />
        </block>
        <block symbolname="cb16re" name="XLXI_7">
            <blockpin signalname="XLXN_12" name="C" />
            <blockpin signalname="PWMOUT" name="CE" />
            <blockpin signalname="PWMBP" name="R" />
            <blockpin name="CEO" />
            <blockpin signalname="PWM_DUTY(15:0)" name="Q(15:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="fd8re" name="XLXI_9">
            <blockpin signalname="XLXN_12" name="C" />
            <blockpin signalname="XLXN_102" name="CE" />
            <blockpin signalname="XLXN_58(7:0)" name="D(7:0)" />
            <blockpin signalname="XLXN_77" name="R" />
            <blockpin signalname="XLXN_15(7:0)" name="Q(7:0)" />
        </block>
        <block symbolname="comp8" name="XLXI_8">
            <blockpin signalname="PWM_DUTY(10:3)" name="A(7:0)" />
            <blockpin signalname="XLXN_15(7:0)" name="B(7:0)" />
            <blockpin signalname="XLXN_103" name="EQ" />
        </block>
        <block symbolname="gnd" name="XLXI_56">
            <blockpin signalname="XLXN_77" name="G" />
        </block>
        <block symbolname="ibuf8" name="XLXI_11">
            <blockpin signalname="SW(7:0)" name="I(7:0)" />
            <blockpin signalname="XLXN_74(7:0)" name="O(7:0)" />
        </block>
        <block symbolname="fd8re" name="XLXI_31">
            <blockpin signalname="XLXN_12" name="C" />
            <blockpin signalname="XLXN_75" name="CE" />
            <blockpin signalname="XLXN_74(7:0)" name="D(7:0)" />
            <blockpin signalname="XLXN_76" name="R" />
            <blockpin signalname="XLXN_58(7:0)" name="Q(7:0)" />
        </block>
        <block symbolname="vcc" name="XLXI_54">
            <blockpin signalname="XLXN_75" name="P" />
        </block>
        <block symbolname="gnd" name="XLXI_55">
            <blockpin signalname="XLXN_76" name="G" />
        </block>
        <block symbolname="vcc" name="XLXI_74">
            <blockpin signalname="XLXN_102" name="P" />
        </block>
        <block symbolname="inv" name="XLXI_10">
            <blockpin signalname="XLXN_103" name="I" />
            <blockpin signalname="PWMOUT" name="O" />
        </block>
        <block symbolname="fd" name="XLXI_75">
            <blockpin signalname="XLXN_12" name="C" />
            <blockpin signalname="PWMOUT" name="D" />
            <blockpin signalname="XLXN_106" name="Q" />
        </block>
        <block symbolname="obuf" name="XLXI_76">
            <blockpin signalname="XLXN_106" name="I" />
            <blockpin signalname="MD1" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_78">
            <blockpin signalname="XLXN_107" name="I" />
            <blockpin signalname="MD2" name="O" />
        </block>
        <block symbolname="buf" name="XLXI_81">
            <blockpin signalname="PWM_BASE(10)" name="I" />
            <blockpin signalname="PWMBP" name="O" />
        </block>
        <block symbolname="vcc" name="XLXI_82">
            <blockpin signalname="XLXN_107" name="P" />
        </block>
    </netlist>
    <sheet sheetnum="1" width="5382" height="3801">
        <attr value="CM" name="LengthUnitName" />
        <attr value="4" name="GridsPerUnit" />
        <instance x="2000" y="1136" name="XLXI_1" orien="R0" />
        <branch name="PWM_BASE(15:0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2496" y="880" type="branch" />
            <wire x2="2496" y1="880" y2="880" x1="2384" />
            <wire x2="2512" y1="880" y2="880" x1="2496" />
            <wire x2="2512" y1="880" y2="1040" x1="2512" />
            <wire x2="2512" y1="1040" y2="1072" x1="2512" />
        </branch>
        <bustap x2="2608" y1="1040" y2="1040" x1="2512" />
        <instance x="1552" y="1040" name="XLXI_5" orien="R0" />
        <branch name="CLK">
            <wire x2="1552" y1="1008" y2="1008" x1="1520" />
        </branch>
        <instance x="1888" y="896" name="XLXI_6" orien="R0" />
        <branch name="XLXN_10">
            <wire x2="1952" y1="896" y2="944" x1="1952" />
            <wire x2="2000" y1="944" y2="944" x1="1952" />
        </branch>
        <instance x="2000" y="1760" name="XLXI_7" orien="R0" />
        <instance x="2000" y="2256" name="XLXI_9" orien="R0" />
        <branch name="XLXN_15(7:0)">
            <wire x2="2736" y1="2000" y2="2000" x1="2384" />
        </branch>
        <branch name="PWM_DUTY(15:0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2480" y="1504" type="branch" />
            <wire x2="2480" y1="1504" y2="1504" x1="2384" />
            <wire x2="2480" y1="1504" y2="1808" x1="2480" />
        </branch>
        <bustap x2="2576" y1="1808" y2="1808" x1="2480" />
        <instance x="2736" y="2128" name="XLXI_8" orien="R0" />
        <branch name="PWM_DUTY(10:3)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2624" y="1808" type="branch" />
            <wire x2="2624" y1="1808" y2="1808" x1="2576" />
            <wire x2="2736" y1="1808" y2="1808" x1="2624" />
        </branch>
        <branch name="XLXN_58(7:0)">
            <wire x2="2000" y1="2000" y2="2000" x1="1808" />
        </branch>
        <instance x="1904" y="2384" name="XLXI_56" orien="R0" />
        <branch name="XLXN_77">
            <wire x2="2000" y1="2224" y2="2224" x1="1968" />
            <wire x2="1968" y1="2224" y2="2256" x1="1968" />
        </branch>
        <branch name="SW(7:0)">
            <wire x2="1056" y1="2000" y2="2000" x1="960" />
        </branch>
        <instance x="1056" y="2032" name="XLXI_11" orien="R0" />
        <branch name="XLXN_74(7:0)">
            <wire x2="1424" y1="2000" y2="2000" x1="1280" />
        </branch>
        <instance x="1424" y="2256" name="XLXI_31" orien="R0" />
        <instance x="1296" y="1936" name="XLXI_54" orien="R0" />
        <branch name="XLXN_75">
            <wire x2="1360" y1="1936" y2="2064" x1="1360" />
            <wire x2="1424" y1="2064" y2="2064" x1="1360" />
        </branch>
        <branch name="XLXN_76">
            <wire x2="1376" y1="2224" y2="2256" x1="1376" />
            <wire x2="1424" y1="2224" y2="2224" x1="1376" />
        </branch>
        <instance x="1312" y="2384" name="XLXI_55" orien="R0" />
        <branch name="XLXN_12">
            <wire x2="1424" y1="2128" y2="2128" x1="1296" />
            <wire x2="1296" y1="2128" y2="2448" x1="1296" />
            <wire x2="1856" y1="2448" y2="2448" x1="1296" />
            <wire x2="3488" y1="2448" y2="2448" x1="1856" />
            <wire x2="1856" y1="1008" y2="1008" x1="1776" />
            <wire x2="2000" y1="1008" y2="1008" x1="1856" />
            <wire x2="1856" y1="1008" y2="1632" x1="1856" />
            <wire x2="2000" y1="1632" y2="1632" x1="1856" />
            <wire x2="1856" y1="1632" y2="2128" x1="1856" />
            <wire x2="2000" y1="2128" y2="2128" x1="1856" />
            <wire x2="1856" y1="2128" y2="2448" x1="1856" />
            <wire x2="3568" y1="2032" y2="2032" x1="3488" />
            <wire x2="3488" y1="2032" y2="2448" x1="3488" />
        </branch>
        <instance x="1888" y="1936" name="XLXI_74" orien="R0" />
        <branch name="XLXN_102">
            <wire x2="1952" y1="1936" y2="2064" x1="1952" />
            <wire x2="2000" y1="2064" y2="2064" x1="1952" />
        </branch>
        <instance x="3200" y="1936" name="XLXI_10" orien="R0" />
        <branch name="XLXN_103">
            <wire x2="3200" y1="1904" y2="1904" x1="3120" />
        </branch>
        <branch name="PWMOUT">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="3438" y="1904" type="branch" />
            <wire x2="1968" y1="1344" y2="1568" x1="1968" />
            <wire x2="2000" y1="1568" y2="1568" x1="1968" />
            <wire x2="3488" y1="1344" y2="1344" x1="1968" />
            <wire x2="3488" y1="1344" y2="1904" x1="3488" />
            <wire x2="3568" y1="1904" y2="1904" x1="3488" />
            <wire x2="3438" y1="1904" y2="1904" x1="3424" />
            <wire x2="3488" y1="1904" y2="1904" x1="3438" />
        </branch>
        <instance x="3568" y="2160" name="XLXI_75" orien="R0" />
        <branch name="MD1">
            <wire x2="4384" y1="1904" y2="1904" x1="4272" />
        </branch>
        <branch name="XLXN_106">
            <wire x2="4048" y1="1904" y2="1904" x1="3952" />
        </branch>
        <instance x="4048" y="1936" name="XLXI_76" orien="R0" />
        <instance x="4048" y="2272" name="XLXI_78" orien="R0" />
        <branch name="XLXN_107">
            <wire x2="3776" y1="2320" y2="2336" x1="3776" />
            <wire x2="3920" y1="2336" y2="2336" x1="3776" />
            <wire x2="4048" y1="2240" y2="2240" x1="3920" />
            <wire x2="3920" y1="2240" y2="2336" x1="3920" />
        </branch>
        <branch name="MD2">
            <wire x2="4384" y1="2240" y2="2240" x1="4272" />
        </branch>
        <iomarker fontsize="28" x="1520" y="1008" name="CLK" orien="R180" />
        <iomarker fontsize="28" x="960" y="2000" name="SW(7:0)" orien="R180" />
        <iomarker fontsize="28" x="4384" y="1904" name="MD1" orien="R0" />
        <iomarker fontsize="28" x="4384" y="2240" name="MD2" orien="R0" />
        <text style="fontsize:48;fontname:Arial" x="4556" y="3192">by Susutawari</text>
        <text style="fontsize:48;fontname:Arial" x="500" y="552">PWM Ctrl</text>
        <rect style="linewidth:W;linecolor:rgb(0,0,0);linestyle:Dash" width="1352" x="1808" y="712" height="516" />
        <rect style="linewidth:W;linecolor:rgb(0,0,0);linestyle:Dash" width="1756" x="1808" y="1316" height="1180" />
        <text style="fontsize:48;fontname:Arial" x="4112" y="1756">To the motor driver</text>
        <text style="fontsize:48;fontname:Arial" x="820" y="1868">Switch Input</text>
        <branch name="PWM_BASE(10)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2672" y="1040" type="branch" />
            <wire x2="2672" y1="1040" y2="1040" x1="2608" />
            <wire x2="2768" y1="1040" y2="1040" x1="2672" />
        </branch>
        <text style="fontsize:48;fontname:Arial" x="1432" y="924">50MHz</text>
        <text style="fontsize:48;fontname:Arial" x="1816" y="676">PWM Base Cycle Generate (48.8kHz@50MHz CLK)</text>
        <branch name="PWMBP">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="3072" y="1040" type="branch" />
            <wire x2="2000" y1="1104" y2="1104" x1="1920" />
            <wire x2="1920" y1="1104" y2="1200" x1="1920" />
            <wire x2="1920" y1="1200" y2="1728" x1="1920" />
            <wire x2="2000" y1="1728" y2="1728" x1="1920" />
            <wire x2="3104" y1="1200" y2="1200" x1="1920" />
            <wire x2="3072" y1="1040" y2="1040" x1="2992" />
            <wire x2="3104" y1="1040" y2="1040" x1="3072" />
            <wire x2="3104" y1="1040" y2="1200" x1="3104" />
        </branch>
        <instance x="2768" y="1072" name="XLXI_81" orien="R0" />
        <text style="fontsize:48;fontname:Arial" x="1816" y="1292">PWM Duty Ratio Generate</text>
        <instance x="3712" y="2320" name="XLXI_82" orien="R0" />
    </sheet>
</drawing>