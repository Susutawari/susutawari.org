<?xml version="1.0" encoding="UTF-8"?>
<drawing version="7">
    <attr value="spartan3e" name="DeviceFamilyName">
        <trait delete="all:0" />
        <trait editname="all:0" />
        <trait edittrait="all:0" />
    </attr>
    <netlist>
        <signal name="XLXN_103" />
        <signal name="FL_EN" />
        <signal name="XLXN_2470" />
        <signal name="XLXN_2251" />
        <signal name="TW7" />
        <signal name="TW7_POS" />
        <signal name="TW7D" />
        <signal name="NEQ" />
        <signal name="FL(7:0)" />
        <signal name="L" />
        <signal name="TW(7)" />
        <signal name="D(7:0)" />
        <signal name="PWMD(15:0)" />
        <signal name="PWMD(10:3)" />
        <signal name="TW(7:0)" />
        <signal name="XLXN_2808" />
        <signal name="XLXN_2809" />
        <signal name="XLXN_2810" />
        <signal name="XLXN_2811" />
        <signal name="XLXN_2812" />
        <signal name="XLXN_2813" />
        <signal name="XLXN_2814" />
        <signal name="XLXN_2815" />
        <signal name="TW(0)" />
        <signal name="TW(1)" />
        <signal name="TW(2)" />
        <signal name="TW(3)" />
        <signal name="TW(4)" />
        <signal name="TW(5)" />
        <signal name="TW(6)" />
        <signal name="TW_UP" />
        <signal name="FL(7)" />
        <signal name="TW7EN" />
        <signal name="CE" />
        <signal name="PWMBP" />
        <signal name="PWMOUT" />
        <signal name="ZERO" />
        <signal name="CLK" />
        <signal name="XLXN_3170" />
        <port polarity="Input" name="L" />
        <port polarity="Input" name="D(7:0)" />
        <port polarity="Input" name="CE" />
        <port polarity="Input" name="PWMBP" />
        <port polarity="Output" name="PWMOUT" />
        <port polarity="Output" name="ZERO" />
        <port polarity="Input" name="CLK" />
        <blockdef name="cb16re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="320" y1="-128" y2="-128" x1="384" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="320" y1="-192" y2="-192" x1="384" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="vcc">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-64" x1="64" />
            <line x2="64" y1="0" y2="-32" x1="64" />
            <line x2="32" y1="-64" y2="-64" x1="96" />
        </blockdef>
        <blockdef name="inv">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="160" y1="-32" y2="-32" x1="224" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="64" y1="0" y2="-64" x1="64" />
            <circle r="16" cx="144" cy="-32" />
        </blockdef>
        <blockdef name="gnd">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-96" x1="64" />
            <line x2="52" y1="-48" y2="-48" x1="76" />
            <line x2="60" y1="-32" y2="-32" x1="68" />
            <line x2="40" y1="-64" y2="-64" x1="88" />
            <line x2="64" y1="-64" y2="-80" x1="64" />
            <line x2="64" y1="-128" y2="-96" x1="64" />
        </blockdef>
        <blockdef name="comp8">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="256" x="64" y="-384" height="320" />
            <line x2="320" y1="-224" y2="-224" x1="384" />
            <rect width="64" x="0" y="-332" height="24" />
            <line x2="64" y1="-320" y2="-320" x1="0" />
            <rect width="64" x="0" y="-140" height="24" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
        </blockdef>
        <blockdef name="fd">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="256" x="64" y="-320" height="256" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
        </blockdef>
        <blockdef name="fdrs">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-352" y2="-352" x1="0" />
            <rect width="256" x="64" y="-320" height="256" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="192" y1="-320" y2="-352" x1="192" />
            <line x2="64" y1="-352" y2="-352" x1="192" />
        </blockdef>
        <blockdef name="and8">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-512" x1="64" />
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="64" y1="-320" y2="-320" x1="0" />
            <line x2="64" y1="-384" y2="-384" x1="0" />
            <line x2="64" y1="-448" y2="-448" x1="0" />
            <line x2="64" y1="-512" y2="-512" x1="0" />
            <line x2="144" y1="-336" y2="-336" x1="64" />
            <line x2="64" y1="-240" y2="-240" x1="144" />
            <arc ex="144" ey="-336" sx="144" sy="-240" r="48" cx="144" cy="-288" />
            <line x2="192" y1="-288" y2="-288" x1="256" />
        </blockdef>
        <blockdef name="and2b1">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-48" y2="-144" x1="64" />
            <line x2="144" y1="-144" y2="-144" x1="64" />
            <line x2="64" y1="-48" y2="-48" x1="144" />
            <arc ex="144" ey="-144" sx="144" sy="-48" r="48" cx="144" cy="-96" />
            <line x2="192" y1="-96" y2="-96" x1="256" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="40" y1="-64" y2="-64" x1="0" />
            <circle r="12" cx="52" cy="-64" />
        </blockdef>
        <blockdef name="or2">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="192" y1="-96" y2="-96" x1="256" />
            <arc ex="192" ey="-96" sx="112" sy="-48" r="88" cx="116" cy="-136" />
            <arc ex="48" ey="-144" sx="48" sy="-48" r="56" cx="16" cy="-96" />
            <line x2="48" y1="-144" y2="-144" x1="112" />
            <arc ex="112" ey="-144" sx="192" sy="-96" r="88" cx="116" cy="-56" />
            <line x2="48" y1="-48" y2="-48" x1="112" />
        </blockdef>
        <blockdef name="and2">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="192" y1="-96" y2="-96" x1="256" />
            <arc ex="144" ey="-144" sx="144" sy="-48" r="48" cx="144" cy="-96" />
            <line x2="64" y1="-48" y2="-48" x1="144" />
            <line x2="144" y1="-144" y2="-144" x1="64" />
            <line x2="64" y1="-48" y2="-144" x1="64" />
        </blockdef>
        <blockdef name="cb8re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="320" y1="-192" y2="-192" x1="384" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="320" y1="-128" y2="-128" x1="384" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="fdre">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <rect width="256" x="64" y="-320" height="256" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
        </blockdef>
        <blockdef name="cb8cled">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="64" x="0" y="-460" height="24" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <rect width="64" x="320" y="-460" height="24" />
            <rect width="256" x="64" y="-512" height="448" />
            <line x2="320" y1="-192" y2="-192" x1="384" />
            <line x2="64" y1="-448" y2="-448" x1="0" />
            <line x2="320" y1="-448" y2="-448" x1="384" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-320" y2="-320" x1="0" />
            <line x2="320" y1="-128" y2="-128" x1="384" />
        </blockdef>
        <block symbolname="gnd" name="XLXI_480">
            <blockpin signalname="XLXN_3170" name="G" />
        </block>
        <block symbolname="cb16re" name="XLXI_7">
            <blockpin signalname="CLK" name="C" />
            <blockpin signalname="NEQ" name="CE" />
            <blockpin signalname="PWMBP" name="R" />
            <blockpin name="CEO" />
            <blockpin signalname="PWMD(15:0)" name="Q(15:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="and2b1" name="XLXI_1463">
            <blockpin signalname="TW7EN" name="I0" />
            <blockpin signalname="CE" name="I1" />
            <blockpin signalname="XLXN_2470" name="O" />
        </block>
        <block symbolname="and2" name="XLXI_1374">
            <blockpin signalname="CE" name="I0" />
            <blockpin signalname="TW7EN" name="I1" />
            <blockpin signalname="FL_EN" name="O" />
        </block>
        <block symbolname="fdre" name="XLXI_1354">
            <blockpin signalname="CLK" name="C" />
            <blockpin signalname="TW7_POS" name="CE" />
            <blockpin signalname="XLXN_2251" name="D" />
            <blockpin signalname="FL(7)" name="R" />
            <blockpin signalname="TW7D" name="Q" />
        </block>
        <block symbolname="vcc" name="XLXI_1355">
            <blockpin signalname="XLXN_2251" name="P" />
        </block>
        <block symbolname="and2b1" name="XLXI_1465">
            <blockpin signalname="TW7" name="I0" />
            <blockpin signalname="TW(7)" name="I1" />
            <blockpin signalname="TW7_POS" name="O" />
        </block>
        <block symbolname="fd" name="XLXI_1464">
            <blockpin signalname="CLK" name="C" />
            <blockpin signalname="TW(7)" name="D" />
            <blockpin signalname="TW7" name="Q" />
        </block>
        <block symbolname="or2" name="XLXI_1360">
            <blockpin signalname="TW7D" name="I0" />
            <blockpin signalname="TW7_POS" name="I1" />
            <blockpin signalname="TW7EN" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_10">
            <blockpin signalname="XLXN_103" name="I" />
            <blockpin signalname="NEQ" name="O" />
        </block>
        <block symbolname="cb8re" name="XLXI_1583">
            <blockpin signalname="CLK" name="C" />
            <blockpin signalname="FL_EN" name="CE" />
            <blockpin signalname="FL(7)" name="R" />
            <blockpin name="CEO" />
            <blockpin signalname="FL(7:0)" name="Q(7:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="cb8cled" name="XLXI_1606">
            <blockpin signalname="CLK" name="C" />
            <blockpin signalname="XLXN_2470" name="CE" />
            <blockpin signalname="XLXN_3170" name="CLR" />
            <blockpin signalname="D(7:0)" name="D(7:0)" />
            <blockpin signalname="L" name="L" />
            <blockpin signalname="TW_UP" name="UP" />
            <blockpin name="CEO" />
            <blockpin signalname="TW(7:0)" name="Q(7:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="comp8" name="XLXI_1618">
            <blockpin signalname="PWMD(10:3)" name="A(7:0)" />
            <blockpin signalname="TW(7:0)" name="B(7:0)" />
            <blockpin signalname="XLXN_103" name="EQ" />
        </block>
        <block symbolname="inv" name="XLXI_1610">
            <blockpin signalname="TW(0)" name="I" />
            <blockpin signalname="XLXN_2815" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1611">
            <blockpin signalname="TW(1)" name="I" />
            <blockpin signalname="XLXN_2814" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1612">
            <blockpin signalname="TW(2)" name="I" />
            <blockpin signalname="XLXN_2813" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1613">
            <blockpin signalname="TW(3)" name="I" />
            <blockpin signalname="XLXN_2812" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1614">
            <blockpin signalname="TW(4)" name="I" />
            <blockpin signalname="XLXN_2811" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1615">
            <blockpin signalname="TW(5)" name="I" />
            <blockpin signalname="XLXN_2810" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1616">
            <blockpin signalname="TW(6)" name="I" />
            <blockpin signalname="XLXN_2809" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1617">
            <blockpin signalname="TW(7)" name="I" />
            <blockpin signalname="XLXN_2808" name="O" />
        </block>
        <block symbolname="and8" name="XLXI_1609">
            <blockpin signalname="XLXN_2808" name="I0" />
            <blockpin signalname="XLXN_2809" name="I1" />
            <blockpin signalname="XLXN_2810" name="I2" />
            <blockpin signalname="XLXN_2811" name="I3" />
            <blockpin signalname="XLXN_2812" name="I4" />
            <blockpin signalname="XLXN_2813" name="I5" />
            <blockpin signalname="XLXN_2814" name="I6" />
            <blockpin signalname="XLXN_2815" name="I7" />
            <blockpin signalname="ZERO" name="O" />
        </block>
        <block symbolname="fdrs" name="XLXI_770">
            <attr value="1" name="INIT">
                <trait verilog="all:0 dp:1" />
                <trait vhdl="all:0 gm:1" />
                <trait valuetype="Bit" />
            </attr>
            <blockpin signalname="CLK" name="C" />
            <blockpin signalname="TW_UP" name="D" />
            <blockpin signalname="FL(7)" name="R" />
            <blockpin signalname="ZERO" name="S" />
            <blockpin signalname="TW_UP" name="Q" />
        </block>
        <block symbolname="fd" name="XLXI_75">
            <blockpin signalname="CLK" name="C" />
            <blockpin signalname="NEQ" name="D" />
            <blockpin signalname="PWMOUT" name="Q" />
        </block>
    </netlist>
    <sheet sheetnum="1" width="5382" height="3801">
        <attr value="CM" name="LengthUnitName" />
        <attr value="4" name="GridsPerUnit" />
        <text style="fontsize:48;fontname:Arial" x="4692" y="3484">by Susutawari</text>
        <text style="fontsize:48;fontname:Arial" x="396" y="428">Trapezoid PWM GEN</text>
        <instance x="1680" y="2096" name="XLXI_480" orien="R0" />
        <instance x="1808" y="1152" name="XLXI_7" orien="R0" />
        <branch name="XLXN_103">
            <wire x2="2944" y1="1168" y2="1168" x1="2896" />
        </branch>
        <branch name="FL_EN">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="3048" y="2736" type="branch" />
            <wire x2="3048" y1="2736" y2="2736" x1="3024" />
            <wire x2="3072" y1="2736" y2="2736" x1="3048" />
        </branch>
        <instance x="1376" y="1888" name="XLXI_1463" orien="R0" />
        <branch name="XLXN_2470">
            <wire x2="1808" y1="1792" y2="1792" x1="1632" />
        </branch>
        <instance x="2768" y="2832" name="XLXI_1374" orien="R0" />
        <branch name="XLXN_2251">
            <wire x2="2224" y1="2640" y2="2672" x1="2224" />
            <wire x2="2256" y1="2672" y2="2672" x1="2224" />
        </branch>
        <instance x="2256" y="2928" name="XLXI_1354" orien="R0" />
        <instance x="2160" y="2640" name="XLXI_1355" orien="R0" />
        <branch name="TW7">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="1826" y="2704" type="branch" />
            <wire x2="1826" y1="2704" y2="2704" x1="1792" />
            <wire x2="1856" y1="2704" y2="2704" x1="1826" />
        </branch>
        <instance x="1856" y="2768" name="XLXI_1465" orien="R0" />
        <instance x="1408" y="2960" name="XLXI_1464" orien="R0" />
        <instance x="2432" y="2448" name="XLXI_1360" orien="R0" />
        <branch name="TW7_POS">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2240" y="2320" type="branch" />
            <wire x2="2160" y1="2672" y2="2672" x1="2112" />
            <wire x2="2160" y1="2672" y2="2736" x1="2160" />
            <wire x2="2256" y1="2736" y2="2736" x1="2160" />
            <wire x2="2160" y1="2320" y2="2672" x1="2160" />
            <wire x2="2240" y1="2320" y2="2320" x1="2160" />
            <wire x2="2432" y1="2320" y2="2320" x1="2240" />
        </branch>
        <branch name="TW7D">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2613" y="2464" type="branch" />
            <wire x2="2432" y1="2384" y2="2384" x1="2368" />
            <wire x2="2368" y1="2384" y2="2464" x1="2368" />
            <wire x2="2613" y1="2464" y2="2464" x1="2368" />
            <wire x2="2656" y1="2464" y2="2464" x1="2613" />
            <wire x2="2656" y1="2464" y2="2672" x1="2656" />
            <wire x2="2656" y1="2672" y2="2672" x1="2640" />
        </branch>
        <instance x="2944" y="1200" name="XLXI_10" orien="R0" />
        <branch name="NEQ">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="3296" y="1168" type="branch" />
            <wire x2="1728" y1="704" y2="960" x1="1728" />
            <wire x2="1808" y1="960" y2="960" x1="1728" />
            <wire x2="3216" y1="704" y2="704" x1="1728" />
            <wire x2="3216" y1="704" y2="1168" x1="3216" />
            <wire x2="3296" y1="1168" y2="1168" x1="3216" />
            <wire x2="3568" y1="1168" y2="1168" x1="3296" />
            <wire x2="3216" y1="1168" y2="1168" x1="3168" />
        </branch>
        <instance x="3072" y="2928" name="XLXI_1583" orien="R0" />
        <branch name="FL(7:0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="3520" y="2672" type="branch" />
            <wire x2="3520" y1="2672" y2="2672" x1="3456" />
            <wire x2="3520" y1="2672" y2="2752" x1="3520" />
        </branch>
        <bustap x2="3616" y1="2752" y2="2752" x1="3520" />
        <instance x="1808" y="1984" name="XLXI_1606" orien="R0" />
        <branch name="TW(7)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2352" y="2016" type="branch" />
            <wire x2="1360" y1="2512" y2="2704" x1="1360" />
            <wire x2="1408" y1="2704" y2="2704" x1="1360" />
            <wire x2="1840" y1="2512" y2="2512" x1="1360" />
            <wire x2="1840" y1="2512" y2="2640" x1="1840" />
            <wire x2="1856" y1="2640" y2="2640" x1="1840" />
            <wire x2="1840" y1="2192" y2="2512" x1="1840" />
            <wire x2="2352" y1="2192" y2="2192" x1="1840" />
            <wire x2="2352" y1="2016" y2="2016" x1="2336" />
            <wire x2="2400" y1="2016" y2="2016" x1="2352" />
            <wire x2="2352" y1="2016" y2="2192" x1="2352" />
        </branch>
        <branch name="D(7:0)">
            <wire x2="1792" y1="1536" y2="1536" x1="1168" />
            <wire x2="1808" y1="1536" y2="1536" x1="1792" />
        </branch>
        <branch name="PWMD(15:0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2288" y="896" type="branch" />
            <wire x2="2288" y1="896" y2="896" x1="2192" />
            <wire x2="2288" y1="896" y2="1072" x1="2288" />
        </branch>
        <instance x="2512" y="1392" name="XLXI_1618" orien="R0" />
        <bustap x2="2384" y1="1072" y2="1072" x1="2288" />
        <branch name="PWMD(10:3)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2416" y="1072" type="branch" />
            <wire x2="2416" y1="1072" y2="1072" x1="2384" />
            <wire x2="2512" y1="1072" y2="1072" x1="2416" />
        </branch>
        <branch name="TW(7:0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2416" y="1264" type="branch" />
            <wire x2="2240" y1="1536" y2="1536" x1="2192" />
            <wire x2="2240" y1="1536" y2="1568" x1="2240" />
            <wire x2="2240" y1="1568" y2="1632" x1="2240" />
            <wire x2="2240" y1="1632" y2="1696" x1="2240" />
            <wire x2="2240" y1="1696" y2="1760" x1="2240" />
            <wire x2="2240" y1="1760" y2="1824" x1="2240" />
            <wire x2="2240" y1="1824" y2="1888" x1="2240" />
            <wire x2="2240" y1="1888" y2="1952" x1="2240" />
            <wire x2="2240" y1="1952" y2="2016" x1="2240" />
            <wire x2="2240" y1="1264" y2="1536" x1="2240" />
            <wire x2="2416" y1="1264" y2="1264" x1="2240" />
            <wire x2="2512" y1="1264" y2="1264" x1="2416" />
        </branch>
        <branch name="XLXN_2808">
            <wire x2="2656" y1="2016" y2="2016" x1="2624" />
        </branch>
        <branch name="XLXN_2809">
            <wire x2="2656" y1="1952" y2="1952" x1="2624" />
        </branch>
        <branch name="XLXN_2810">
            <wire x2="2656" y1="1888" y2="1888" x1="2624" />
        </branch>
        <branch name="XLXN_2811">
            <wire x2="2656" y1="1824" y2="1824" x1="2624" />
        </branch>
        <branch name="XLXN_2812">
            <wire x2="2656" y1="1760" y2="1760" x1="2624" />
        </branch>
        <branch name="XLXN_2813">
            <wire x2="2656" y1="1696" y2="1696" x1="2624" />
        </branch>
        <branch name="XLXN_2814">
            <wire x2="2656" y1="1632" y2="1632" x1="2624" />
        </branch>
        <branch name="XLXN_2815">
            <wire x2="2656" y1="1568" y2="1568" x1="2624" />
        </branch>
        <instance x="2400" y="1600" name="XLXI_1610" orien="R0" />
        <instance x="2400" y="1664" name="XLXI_1611" orien="R0" />
        <instance x="2400" y="1728" name="XLXI_1612" orien="R0" />
        <instance x="2400" y="1792" name="XLXI_1613" orien="R0" />
        <instance x="2400" y="1856" name="XLXI_1614" orien="R0" />
        <instance x="2400" y="1920" name="XLXI_1615" orien="R0" />
        <instance x="2400" y="1984" name="XLXI_1616" orien="R0" />
        <instance x="2400" y="2048" name="XLXI_1617" orien="R0" />
        <instance x="2656" y="2080" name="XLXI_1609" orien="R0" />
        <bustap x2="2336" y1="1568" y2="1568" x1="2240" />
        <bustap x2="2336" y1="1632" y2="1632" x1="2240" />
        <bustap x2="2336" y1="1696" y2="1696" x1="2240" />
        <bustap x2="2336" y1="1760" y2="1760" x1="2240" />
        <bustap x2="2336" y1="1824" y2="1824" x1="2240" />
        <bustap x2="2336" y1="1888" y2="1888" x1="2240" />
        <bustap x2="2336" y1="1952" y2="1952" x1="2240" />
        <bustap x2="2336" y1="2016" y2="2016" x1="2240" />
        <branch name="TW(0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2352" y="1568" type="branch" />
            <wire x2="2352" y1="1568" y2="1568" x1="2336" />
            <wire x2="2400" y1="1568" y2="1568" x1="2352" />
        </branch>
        <branch name="TW(1)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2352" y="1632" type="branch" />
            <wire x2="2352" y1="1632" y2="1632" x1="2336" />
            <wire x2="2400" y1="1632" y2="1632" x1="2352" />
        </branch>
        <branch name="TW(2)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2352" y="1696" type="branch" />
            <wire x2="2352" y1="1696" y2="1696" x1="2336" />
            <wire x2="2400" y1="1696" y2="1696" x1="2352" />
        </branch>
        <branch name="TW(3)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2352" y="1760" type="branch" />
            <wire x2="2352" y1="1760" y2="1760" x1="2336" />
            <wire x2="2400" y1="1760" y2="1760" x1="2352" />
        </branch>
        <branch name="TW(4)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2352" y="1824" type="branch" />
            <wire x2="2352" y1="1824" y2="1824" x1="2336" />
            <wire x2="2400" y1="1824" y2="1824" x1="2352" />
        </branch>
        <branch name="TW(5)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2352" y="1888" type="branch" />
            <wire x2="2352" y1="1888" y2="1888" x1="2336" />
            <wire x2="2400" y1="1888" y2="1888" x1="2352" />
        </branch>
        <branch name="TW(6)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2352" y="1952" type="branch" />
            <wire x2="2352" y1="1952" y2="1952" x1="2336" />
            <wire x2="2400" y1="1952" y2="1952" x1="2352" />
        </branch>
        <branch name="TW_UP">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="3712" y="1808" type="branch" />
            <wire x2="1808" y1="1664" y2="1664" x1="1648" />
            <wire x2="1648" y1="1664" y2="2144" x1="1648" />
            <wire x2="3760" y1="2144" y2="2144" x1="1648" />
            <wire x2="3232" y1="1616" y2="1808" x1="3232" />
            <wire x2="3296" y1="1808" y2="1808" x1="3232" />
            <wire x2="3760" y1="1616" y2="1616" x1="3232" />
            <wire x2="3760" y1="1616" y2="1808" x1="3760" />
            <wire x2="3760" y1="1808" y2="2144" x1="3760" />
            <wire x2="3712" y1="1808" y2="1808" x1="3680" />
            <wire x2="3760" y1="1808" y2="1808" x1="3712" />
        </branch>
        <instance x="3296" y="2064" name="XLXI_770" orien="R0">
            <attrtext style="fontsize:28;fontname:Arial;displayformat:NAMEEQUALSVALUE" attrname="INIT" x="304" y="-384" type="instance" />
        </instance>
        <branch name="FL(7)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="3632" y="2752" type="branch" />
            <wire x2="2256" y1="2896" y2="2896" x1="2224" />
            <wire x2="2224" y1="2896" y2="2976" x1="2224" />
            <wire x2="3056" y1="2976" y2="2976" x1="2224" />
            <wire x2="3696" y1="2976" y2="2976" x1="3056" />
            <wire x2="3072" y1="2896" y2="2896" x1="3056" />
            <wire x2="3056" y1="2896" y2="2976" x1="3056" />
            <wire x2="3296" y1="2032" y2="2288" x1="3296" />
            <wire x2="3696" y1="2288" y2="2288" x1="3296" />
            <wire x2="3696" y1="2288" y2="2752" x1="3696" />
            <wire x2="3696" y1="2752" y2="2976" x1="3696" />
            <wire x2="3632" y1="2752" y2="2752" x1="3616" />
            <wire x2="3696" y1="2752" y2="2752" x1="3632" />
        </branch>
        <branch name="TW7EN">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2704" y="2352" type="branch" />
            <wire x2="1376" y1="1824" y2="1824" x1="1360" />
            <wire x2="1360" y1="1824" y2="2240" x1="1360" />
            <wire x2="2752" y1="2240" y2="2240" x1="1360" />
            <wire x2="2752" y1="2240" y2="2352" x1="2752" />
            <wire x2="2752" y1="2352" y2="2704" x1="2752" />
            <wire x2="2768" y1="2704" y2="2704" x1="2752" />
            <wire x2="2704" y1="2352" y2="2352" x1="2688" />
            <wire x2="2752" y1="2352" y2="2352" x1="2704" />
        </branch>
        <instance x="3568" y="1424" name="XLXI_75" orien="R0" />
        <branch name="CE">
            <wire x2="1184" y1="1760" y2="1760" x1="864" />
            <wire x2="1376" y1="1760" y2="1760" x1="1184" />
            <wire x2="1184" y1="1760" y2="3136" x1="1184" />
            <wire x2="2736" y1="3136" y2="3136" x1="1184" />
            <wire x2="2768" y1="2768" y2="2768" x1="2736" />
            <wire x2="2736" y1="2768" y2="3136" x1="2736" />
        </branch>
        <branch name="PWMBP">
            <wire x2="1792" y1="1120" y2="1120" x1="1248" />
            <wire x2="1808" y1="1120" y2="1120" x1="1792" />
        </branch>
        <branch name="PWMOUT">
            <wire x2="4224" y1="1168" y2="1168" x1="3952" />
        </branch>
        <branch name="ZERO">
            <wire x2="3152" y1="1792" y2="1792" x1="2912" />
            <wire x2="3152" y1="1552" y2="1712" x1="3152" />
            <wire x2="3152" y1="1712" y2="1792" x1="3152" />
            <wire x2="3296" y1="1712" y2="1712" x1="3152" />
            <wire x2="4224" y1="1552" y2="1552" x1="3152" />
        </branch>
        <iomarker fontsize="28" x="912" y="3024" name="CLK" orien="R180" />
        <iomarker fontsize="28" x="864" y="1760" name="CE" orien="R180" />
        <branch name="CLK">
            <wire x2="1088" y1="3024" y2="3024" x1="912" />
            <wire x2="1360" y1="3024" y2="3024" x1="1088" />
            <wire x2="2176" y1="3024" y2="3024" x1="1360" />
            <wire x2="3008" y1="3024" y2="3024" x1="2176" />
            <wire x2="3920" y1="3024" y2="3024" x1="3008" />
            <wire x2="1680" y1="2048" y2="2048" x1="1088" />
            <wire x2="1088" y1="2048" y2="3024" x1="1088" />
            <wire x2="1408" y1="2832" y2="2832" x1="1360" />
            <wire x2="1360" y1="2832" y2="3024" x1="1360" />
            <wire x2="1808" y1="1024" y2="1024" x1="1680" />
            <wire x2="1680" y1="1024" y2="1856" x1="1680" />
            <wire x2="1808" y1="1856" y2="1856" x1="1680" />
            <wire x2="1680" y1="1856" y2="2048" x1="1680" />
            <wire x2="2256" y1="2800" y2="2800" x1="2176" />
            <wire x2="2176" y1="2800" y2="3024" x1="2176" />
            <wire x2="3072" y1="2800" y2="2800" x1="3008" />
            <wire x2="3008" y1="2800" y2="3024" x1="3008" />
            <wire x2="3568" y1="1296" y2="1296" x1="3072" />
            <wire x2="3072" y1="1296" y2="1936" x1="3072" />
            <wire x2="3296" y1="1936" y2="1936" x1="3072" />
            <wire x2="3072" y1="1936" y2="2096" x1="3072" />
            <wire x2="3920" y1="2096" y2="2096" x1="3072" />
            <wire x2="3920" y1="2096" y2="3024" x1="3920" />
        </branch>
        <iomarker fontsize="28" x="4224" y="1168" name="PWMOUT" orien="R0" />
        <iomarker fontsize="28" x="4224" y="1552" name="ZERO" orien="R0" />
        <branch name="L">
            <wire x2="1792" y1="1616" y2="1616" x1="1104" />
            <wire x2="1792" y1="1616" y2="1728" x1="1792" />
            <wire x2="1808" y1="1728" y2="1728" x1="1792" />
        </branch>
        <branch name="XLXN_3170">
            <wire x2="1744" y1="1952" y2="1968" x1="1744" />
            <wire x2="1808" y1="1952" y2="1952" x1="1744" />
        </branch>
        <iomarker fontsize="28" x="1248" y="1120" name="PWMBP" orien="R180" />
        <iomarker fontsize="28" x="1168" y="1536" name="D(7:0)" orien="R180" />
        <iomarker fontsize="28" x="1104" y="1616" name="L" orien="R180" />
    </sheet>
</drawing>