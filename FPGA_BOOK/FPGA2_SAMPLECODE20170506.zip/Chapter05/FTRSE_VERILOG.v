module FTRSE_VERILOG(CLK, R, S, T, CE, Q);

    input  CLK;
    input  R;
    input  S;
    input  T;
    input  CE;
    output Q;

    reg    Q;

    always @(posedge CLK) begin
        if (R == 1'b1) begin
            Q <= 1'b0;
        end
        else if (S == 1'b1) begin
            Q <= 1'b1;
        end
        else if (CE == 1'b1 && T == 1'b1) begin
            Q <= ~Q;
        end
    end

endmodule
