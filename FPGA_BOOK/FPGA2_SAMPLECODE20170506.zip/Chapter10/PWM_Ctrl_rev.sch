<?xml version="1.0" encoding="UTF-8"?>
<drawing version="7">
    <attr value="spartan3e" name="DeviceFamilyName">
        <trait delete="all:0" />
        <trait editname="all:0" />
        <trait edittrait="all:0" />
    </attr>
    <netlist>
        <signal name="PWM_BASE(15:0)" />
        <signal name="CLK" />
        <signal name="XLXN_10" />
        <signal name="XLXN_15(7:0)" />
        <signal name="PWM_DUTY(15:0)" />
        <signal name="PWM_DUTY(10:3)" />
        <signal name="XLXN_58(7:0)" />
        <signal name="XLXN_77" />
        <signal name="SW(7:0)" />
        <signal name="XLXN_74(7:0)" />
        <signal name="XLXN_75" />
        <signal name="XLXN_76" />
        <signal name="XLXN_102" />
        <signal name="XLXN_103" />
        <signal name="XLXN_287" />
        <signal name="PWMOUT" />
        <signal name="PWM_BASE(10)" />
        <signal name="XLXN_289" />
        <signal name="PWMBP" />
        <signal name="XLXN_130" />
        <signal name="XLXN_155" />
        <signal name="XLXN_156" />
        <signal name="PSW0" />
        <signal name="XLXN_173" />
        <signal name="XLXN_174" />
        <signal name="XLXN_301" />
        <signal name="XLXN_175" />
        <signal name="XLXN_303" />
        <signal name="XLXN_176" />
        <signal name="LED0" />
        <signal name="XLXN_160" />
        <signal name="XLXN_161" />
        <signal name="XLXN_180" />
        <signal name="XLXN_309" />
        <signal name="XLXN_310" />
        <signal name="XLXN_311" />
        <signal name="XLXN_312" />
        <signal name="XLXN_313" />
        <signal name="XLXN_314" />
        <signal name="XLXN_181" />
        <signal name="XLXN_316" />
        <signal name="XLXN_317" />
        <signal name="XLXN_318" />
        <signal name="XLXN_182" />
        <signal name="MD2" />
        <signal name="MD1" />
        <signal name="XLXN_171" />
        <signal name="XLXN_172" />
        <signal name="XLXN_330" />
        <signal name="XLXN_331" />
        <port polarity="Input" name="CLK" />
        <port polarity="Input" name="SW(7:0)" />
        <port polarity="Input" name="PSW0" />
        <port polarity="Output" name="LED0" />
        <port polarity="Output" name="MD2" />
        <port polarity="Output" name="MD1" />
        <blockdef name="cb16re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="320" y1="-128" y2="-128" x1="384" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="320" y1="-192" y2="-192" x1="384" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="ibufg">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
        </blockdef>
        <blockdef name="vcc">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-64" x1="64" />
            <line x2="64" y1="0" y2="-32" x1="64" />
            <line x2="32" y1="-64" y2="-64" x1="96" />
        </blockdef>
        <blockdef name="comp8">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="256" x="64" y="-384" height="320" />
            <line x2="320" y1="-224" y2="-224" x1="384" />
            <rect width="64" x="0" y="-332" height="24" />
            <line x2="64" y1="-320" y2="-320" x1="0" />
            <rect width="64" x="0" y="-140" height="24" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
        </blockdef>
        <blockdef name="fd8re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <rect width="64" x="0" y="-268" height="24" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="inv">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="160" y1="-32" y2="-32" x1="224" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="64" y1="0" y2="-64" x1="64" />
            <circle r="16" cx="144" cy="-32" />
        </blockdef>
        <blockdef name="ibuf8">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="96" x="128" y="-44" height="24" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <rect width="64" x="0" y="-44" height="24" />
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
        </blockdef>
        <blockdef name="gnd">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-96" x1="64" />
            <line x2="52" y1="-48" y2="-48" x1="76" />
            <line x2="60" y1="-32" y2="-32" x1="68" />
            <line x2="40" y1="-64" y2="-64" x1="88" />
            <line x2="64" y1="-64" y2="-80" x1="64" />
            <line x2="64" y1="-128" y2="-96" x1="64" />
        </blockdef>
        <blockdef name="fd">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="256" x="64" y="-320" height="256" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
        </blockdef>
        <blockdef name="obuf">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
        </blockdef>
        <blockdef name="and2">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="192" y1="-96" y2="-96" x1="256" />
            <arc ex="144" ey="-144" sx="144" sy="-48" r="48" cx="144" cy="-96" />
            <line x2="64" y1="-48" y2="-48" x1="144" />
            <line x2="144" y1="-144" y2="-144" x1="64" />
            <line x2="64" y1="-48" y2="-144" x1="64" />
        </blockdef>
        <blockdef name="and2b1">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-48" y2="-144" x1="64" />
            <line x2="144" y1="-144" y2="-144" x1="64" />
            <line x2="64" y1="-48" y2="-48" x1="144" />
            <arc ex="144" ey="-144" sx="144" sy="-48" r="48" cx="144" cy="-96" />
            <line x2="192" y1="-96" y2="-96" x1="256" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="40" y1="-64" y2="-64" x1="0" />
            <circle r="12" cx="52" cy="-64" />
        </blockdef>
        <blockdef name="ibuf">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
        </blockdef>
        <blockdef name="fdre">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <rect width="256" x="64" y="-320" height="256" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
        </blockdef>
        <blockdef name="ftce">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="cb8re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="320" y1="-192" y2="-192" x1="384" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="320" y1="-128" y2="-128" x1="384" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="buf">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <line x2="128" y1="0" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-64" x1="128" />
            <line x2="64" y1="-64" y2="0" x1="64" />
        </blockdef>
        <block symbolname="cb16re" name="XLXI_1">
            <blockpin signalname="XLXN_181" name="C" />
            <blockpin signalname="XLXN_10" name="CE" />
            <blockpin signalname="PWMBP" name="R" />
            <blockpin name="CEO" />
            <blockpin signalname="PWM_BASE(15:0)" name="Q(15:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="ibufg" name="XLXI_5">
            <blockpin signalname="CLK" name="I" />
            <blockpin signalname="XLXN_181" name="O" />
        </block>
        <block symbolname="vcc" name="XLXI_6">
            <blockpin signalname="XLXN_10" name="P" />
        </block>
        <block symbolname="cb16re" name="XLXI_7">
            <blockpin signalname="XLXN_181" name="C" />
            <blockpin signalname="PWMOUT" name="CE" />
            <blockpin signalname="PWMBP" name="R" />
            <blockpin name="CEO" />
            <blockpin signalname="PWM_DUTY(15:0)" name="Q(15:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="fd8re" name="XLXI_9">
            <blockpin signalname="XLXN_181" name="C" />
            <blockpin signalname="XLXN_102" name="CE" />
            <blockpin signalname="XLXN_58(7:0)" name="D(7:0)" />
            <blockpin signalname="XLXN_77" name="R" />
            <blockpin signalname="XLXN_15(7:0)" name="Q(7:0)" />
        </block>
        <block symbolname="comp8" name="XLXI_8">
            <blockpin signalname="PWM_DUTY(10:3)" name="A(7:0)" />
            <blockpin signalname="XLXN_15(7:0)" name="B(7:0)" />
            <blockpin signalname="XLXN_103" name="EQ" />
        </block>
        <block symbolname="gnd" name="XLXI_56">
            <blockpin signalname="XLXN_77" name="G" />
        </block>
        <block symbolname="ibuf8" name="XLXI_11">
            <blockpin signalname="SW(7:0)" name="I(7:0)" />
            <blockpin signalname="XLXN_74(7:0)" name="O(7:0)" />
        </block>
        <block symbolname="fd8re" name="XLXI_31">
            <blockpin signalname="XLXN_181" name="C" />
            <blockpin signalname="XLXN_75" name="CE" />
            <blockpin signalname="XLXN_74(7:0)" name="D(7:0)" />
            <blockpin signalname="XLXN_76" name="R" />
            <blockpin signalname="XLXN_58(7:0)" name="Q(7:0)" />
        </block>
        <block symbolname="vcc" name="XLXI_54">
            <blockpin signalname="XLXN_75" name="P" />
        </block>
        <block symbolname="gnd" name="XLXI_55">
            <blockpin signalname="XLXN_76" name="G" />
        </block>
        <block symbolname="vcc" name="XLXI_74">
            <blockpin signalname="XLXN_102" name="P" />
        </block>
        <block symbolname="inv" name="XLXI_10">
            <blockpin signalname="XLXN_103" name="I" />
            <blockpin signalname="PWMOUT" name="O" />
        </block>
        <block symbolname="fd" name="XLXI_75">
            <blockpin signalname="XLXN_181" name="C" />
            <blockpin signalname="PWMOUT" name="D" />
            <blockpin signalname="XLXN_130" name="Q" />
        </block>
        <block symbolname="and2" name="XLXI_85">
            <blockpin signalname="XLXN_176" name="I0" />
            <blockpin signalname="XLXN_130" name="I1" />
            <blockpin signalname="XLXN_174" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_86">
            <blockpin signalname="XLXN_176" name="I0" />
            <blockpin signalname="XLXN_130" name="I1" />
            <blockpin signalname="XLXN_173" name="O" />
        </block>
        <block symbolname="fdre" name="XLXI_104">
            <blockpin signalname="XLXN_181" name="C" />
            <blockpin signalname="XLXN_155" name="CE" />
            <blockpin signalname="XLXN_156" name="D" />
            <blockpin signalname="XLXN_182" name="R" />
            <blockpin signalname="XLXN_175" name="Q" />
        </block>
        <block symbolname="vcc" name="XLXI_105">
            <blockpin signalname="XLXN_156" name="P" />
        </block>
        <block symbolname="cb16re" name="XLXI_106">
            <blockpin signalname="XLXN_181" name="C" />
            <blockpin signalname="XLXN_175" name="CE" />
            <blockpin signalname="XLXN_182" name="R" />
            <blockpin signalname="XLXN_180" name="CEO" />
            <blockpin name="Q(15:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="ibuf" name="XLXI_102">
            <blockpin signalname="PSW0" name="I" />
            <blockpin signalname="XLXN_155" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_118">
            <blockpin signalname="XLXN_176" name="I" />
            <blockpin signalname="LED0" name="O" />
        </block>
        <block symbolname="ftce" name="XLXI_107">
            <blockpin signalname="XLXN_181" name="C" />
            <blockpin signalname="XLXN_182" name="CE" />
            <blockpin signalname="XLXN_161" name="CLR" />
            <blockpin signalname="XLXN_160" name="T" />
            <blockpin signalname="XLXN_176" name="Q" />
        </block>
        <block symbolname="vcc" name="XLXI_108">
            <blockpin signalname="XLXN_160" name="P" />
        </block>
        <block symbolname="gnd" name="XLXI_109">
            <blockpin signalname="XLXN_161" name="G" />
        </block>
        <block symbolname="cb8re" name="XLXI_123">
            <blockpin signalname="XLXN_181" name="C" />
            <blockpin signalname="XLXN_180" name="CE" />
            <blockpin signalname="XLXN_182" name="R" />
            <blockpin signalname="XLXN_182" name="CEO" />
            <blockpin name="Q(7:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="buf" name="XLXI_126">
            <blockpin signalname="PWM_BASE(10)" name="I" />
            <blockpin signalname="PWMBP" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_78">
            <blockpin signalname="XLXN_172" name="I" />
            <blockpin signalname="MD2" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_76">
            <blockpin signalname="XLXN_171" name="I" />
            <blockpin signalname="MD1" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_124">
            <blockpin signalname="XLXN_175" name="I0" />
            <blockpin signalname="XLXN_330" name="I1" />
            <blockpin signalname="XLXN_171" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_125">
            <blockpin signalname="XLXN_175" name="I0" />
            <blockpin signalname="XLXN_331" name="I1" />
            <blockpin signalname="XLXN_172" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_165">
            <blockpin signalname="XLXN_174" name="I" />
            <blockpin signalname="XLXN_330" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_166">
            <blockpin signalname="XLXN_173" name="I" />
            <blockpin signalname="XLXN_331" name="O" />
        </block>
    </netlist>
    <sheet sheetnum="1" width="5382" height="3801">
        <attr value="CM" name="LengthUnitName" />
        <attr value="4" name="GridsPerUnit" />
        <text style="fontsize:48;fontname:Arial" x="308" y="408">PWM Ctrl</text>
        <instance x="1520" y="1008" name="XLXI_1" orien="R0" />
        <branch name="PWM_BASE(15:0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2016" y="752" type="branch" />
            <wire x2="2016" y1="752" y2="752" x1="1904" />
            <wire x2="2032" y1="752" y2="752" x1="2016" />
            <wire x2="2032" y1="752" y2="848" x1="2032" />
        </branch>
        <instance x="1072" y="912" name="XLXI_5" orien="R0" />
        <branch name="CLK">
            <wire x2="1072" y1="880" y2="880" x1="1040" />
        </branch>
        <instance x="1408" y="768" name="XLXI_6" orien="R0" />
        <branch name="XLXN_10">
            <wire x2="1472" y1="768" y2="816" x1="1472" />
            <wire x2="1520" y1="816" y2="816" x1="1472" />
        </branch>
        <instance x="1520" y="1632" name="XLXI_7" orien="R0" />
        <instance x="1520" y="2128" name="XLXI_9" orien="R0" />
        <branch name="XLXN_15(7:0)">
            <wire x2="2256" y1="1872" y2="1872" x1="1904" />
        </branch>
        <branch name="PWM_DUTY(15:0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2000" y="1376" type="branch" />
            <wire x2="2000" y1="1376" y2="1376" x1="1904" />
            <wire x2="2000" y1="1376" y2="1680" x1="2000" />
        </branch>
        <bustap x2="2096" y1="1680" y2="1680" x1="2000" />
        <instance x="2256" y="2000" name="XLXI_8" orien="R0" />
        <branch name="PWM_DUTY(10:3)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2144" y="1680" type="branch" />
            <wire x2="2144" y1="1680" y2="1680" x1="2096" />
            <wire x2="2256" y1="1680" y2="1680" x1="2144" />
        </branch>
        <branch name="XLXN_58(7:0)">
            <wire x2="1520" y1="1872" y2="1872" x1="1328" />
        </branch>
        <instance x="1424" y="2256" name="XLXI_56" orien="R0" />
        <branch name="XLXN_77">
            <wire x2="1520" y1="2096" y2="2096" x1="1488" />
            <wire x2="1488" y1="2096" y2="2128" x1="1488" />
        </branch>
        <branch name="SW(7:0)">
            <wire x2="576" y1="1872" y2="1872" x1="480" />
        </branch>
        <instance x="576" y="1904" name="XLXI_11" orien="R0" />
        <branch name="XLXN_74(7:0)">
            <wire x2="944" y1="1872" y2="1872" x1="800" />
        </branch>
        <instance x="944" y="2128" name="XLXI_31" orien="R0" />
        <instance x="816" y="1808" name="XLXI_54" orien="R0" />
        <branch name="XLXN_75">
            <wire x2="880" y1="1808" y2="1936" x1="880" />
            <wire x2="944" y1="1936" y2="1936" x1="880" />
        </branch>
        <branch name="XLXN_76">
            <wire x2="896" y1="2096" y2="2128" x1="896" />
            <wire x2="944" y1="2096" y2="2096" x1="896" />
        </branch>
        <instance x="832" y="2256" name="XLXI_55" orien="R0" />
        <instance x="1408" y="1808" name="XLXI_74" orien="R0" />
        <branch name="XLXN_102">
            <wire x2="1472" y1="1808" y2="1936" x1="1472" />
            <wire x2="1520" y1="1936" y2="1936" x1="1472" />
        </branch>
        <instance x="2720" y="1808" name="XLXI_10" orien="R0" />
        <branch name="XLXN_103">
            <wire x2="2720" y1="1776" y2="1776" x1="2640" />
        </branch>
        <branch name="PWMOUT">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2976" y="1776" type="branch" />
            <wire x2="1488" y1="1216" y2="1440" x1="1488" />
            <wire x2="1520" y1="1440" y2="1440" x1="1488" />
            <wire x2="3024" y1="1216" y2="1216" x1="1488" />
            <wire x2="3024" y1="1216" y2="1776" x1="3024" />
            <wire x2="3088" y1="1776" y2="1776" x1="3024" />
            <wire x2="2976" y1="1776" y2="1776" x1="2944" />
            <wire x2="3024" y1="1776" y2="1776" x1="2976" />
        </branch>
        <instance x="3088" y="2032" name="XLXI_75" orien="R0" />
        <text style="fontsize:48;fontname:Arial" x="4076" y="3064">by Susutawari</text>
        <rect style="linewidth:W;linecolor:rgb(0,0,255);linestyle:Dash" width="1352" x="1328" y="584" height="516" />
        <rect style="linewidth:W;linecolor:rgb(0,0,255);linestyle:Dash" width="1756" x="1328" y="1188" height="1164" />
        <text style="fontsize:48;fontname:Arial" x="340" y="1740">Switch Input</text>
        <bustap x2="2128" y1="848" y2="848" x1="2032" />
        <branch name="PWM_BASE(10)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2192" y="848" type="branch" />
            <wire x2="2192" y1="848" y2="848" x1="2128" />
            <wire x2="2288" y1="848" y2="848" x1="2192" />
        </branch>
        <branch name="PWMBP">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2576" y="848" type="branch" />
            <wire x2="1520" y1="976" y2="976" x1="1440" />
            <wire x2="1440" y1="976" y2="1072" x1="1440" />
            <wire x2="1440" y1="1072" y2="1600" x1="1440" />
            <wire x2="1520" y1="1600" y2="1600" x1="1440" />
            <wire x2="2624" y1="1072" y2="1072" x1="1440" />
            <wire x2="2576" y1="848" y2="848" x1="2512" />
            <wire x2="2624" y1="848" y2="848" x1="2576" />
            <wire x2="2624" y1="848" y2="1072" x1="2624" />
        </branch>
        <instance x="3696" y="1904" name="XLXI_85" orien="R0" />
        <instance x="3696" y="2096" name="XLXI_86" orien="R0" />
        <branch name="XLXN_130">
            <wire x2="3600" y1="1776" y2="1776" x1="3472" />
            <wire x2="3600" y1="1776" y2="1968" x1="3600" />
            <wire x2="3696" y1="1968" y2="1968" x1="3600" />
            <wire x2="3696" y1="1776" y2="1776" x1="3600" />
        </branch>
        <instance x="976" y="2944" name="XLXI_104" orien="R0" />
        <instance x="864" y="2640" name="XLXI_105" orien="R0" />
        <branch name="XLXN_155">
            <wire x2="976" y1="2752" y2="2752" x1="752" />
        </branch>
        <branch name="XLXN_156">
            <wire x2="928" y1="2640" y2="2688" x1="928" />
            <wire x2="976" y1="2688" y2="2688" x1="928" />
        </branch>
        <instance x="1600" y="2880" name="XLXI_106" orien="R0" />
        <instance x="528" y="2784" name="XLXI_102" orien="R0" />
        <branch name="PSW0">
            <wire x2="528" y1="2752" y2="2752" x1="432" />
        </branch>
        <branch name="XLXN_176">
            <wire x2="3648" y1="2688" y2="2688" x1="3248" />
            <wire x2="3776" y1="2688" y2="2688" x1="3648" />
            <wire x2="3648" y1="1840" y2="2032" x1="3648" />
            <wire x2="3696" y1="2032" y2="2032" x1="3648" />
            <wire x2="3648" y1="2032" y2="2688" x1="3648" />
            <wire x2="3696" y1="1840" y2="1840" x1="3648" />
        </branch>
        <instance x="3776" y="2720" name="XLXI_118" orien="R0" />
        <branch name="LED0">
            <wire x2="4064" y1="2688" y2="2688" x1="4000" />
        </branch>
        <instance x="2864" y="2944" name="XLXI_107" orien="R0" />
        <instance x="2752" y="2656" name="XLXI_108" orien="R0" />
        <branch name="XLXN_160">
            <wire x2="2816" y1="2656" y2="2688" x1="2816" />
            <wire x2="2864" y1="2688" y2="2688" x1="2816" />
        </branch>
        <instance x="2768" y="3072" name="XLXI_109" orien="R0" />
        <branch name="XLXN_161">
            <wire x2="2864" y1="2912" y2="2912" x1="2832" />
            <wire x2="2832" y1="2912" y2="2944" x1="2832" />
        </branch>
        <instance x="2144" y="2880" name="XLXI_123" orien="R0" />
        <branch name="XLXN_180">
            <wire x2="2144" y1="2688" y2="2688" x1="1984" />
        </branch>
        <branch name="XLXN_181">
            <wire x2="944" y1="2000" y2="2000" x1="816" />
            <wire x2="816" y1="2000" y2="2320" x1="816" />
            <wire x2="1376" y1="2320" y2="2320" x1="816" />
            <wire x2="3008" y1="2320" y2="2320" x1="1376" />
            <wire x2="816" y1="2320" y2="3056" x1="816" />
            <wire x2="944" y1="3056" y2="3056" x1="816" />
            <wire x2="1520" y1="3056" y2="3056" x1="944" />
            <wire x2="2048" y1="3056" y2="3056" x1="1520" />
            <wire x2="2752" y1="3056" y2="3056" x1="2048" />
            <wire x2="976" y1="2816" y2="2816" x1="944" />
            <wire x2="944" y1="2816" y2="3056" x1="944" />
            <wire x2="1376" y1="880" y2="880" x1="1296" />
            <wire x2="1520" y1="880" y2="880" x1="1376" />
            <wire x2="1376" y1="880" y2="1504" x1="1376" />
            <wire x2="1520" y1="1504" y2="1504" x1="1376" />
            <wire x2="1376" y1="1504" y2="2000" x1="1376" />
            <wire x2="1520" y1="2000" y2="2000" x1="1376" />
            <wire x2="1376" y1="2000" y2="2320" x1="1376" />
            <wire x2="1600" y1="2752" y2="2752" x1="1520" />
            <wire x2="1520" y1="2752" y2="3056" x1="1520" />
            <wire x2="2144" y1="2752" y2="2752" x1="2048" />
            <wire x2="2048" y1="2752" y2="3056" x1="2048" />
            <wire x2="2864" y1="2816" y2="2816" x1="2752" />
            <wire x2="2752" y1="2816" y2="3056" x1="2752" />
            <wire x2="3088" y1="1904" y2="1904" x1="3008" />
            <wire x2="3008" y1="1904" y2="2320" x1="3008" />
        </branch>
        <branch name="XLXN_182">
            <wire x2="976" y1="2912" y2="2992" x1="976" />
            <wire x2="1584" y1="2992" y2="2992" x1="976" />
            <wire x2="2096" y1="2992" y2="2992" x1="1584" />
            <wire x2="2624" y1="2992" y2="2992" x1="2096" />
            <wire x2="1600" y1="2848" y2="2848" x1="1584" />
            <wire x2="1584" y1="2848" y2="2992" x1="1584" />
            <wire x2="2144" y1="2848" y2="2848" x1="2096" />
            <wire x2="2096" y1="2848" y2="2992" x1="2096" />
            <wire x2="2624" y1="2688" y2="2688" x1="2528" />
            <wire x2="2624" y1="2688" y2="2752" x1="2624" />
            <wire x2="2864" y1="2752" y2="2752" x1="2624" />
            <wire x2="2624" y1="2752" y2="2992" x1="2624" />
        </branch>
        <rect style="linecolor:rgb(0,0,255);linestyle:Dash" width="404" x="3536" y="1672" height="476" />
        <rect style="linecolor:rgb(0,0,255);linestyle:Dash" width="2472" x="876" y="2416" height="728" />
        <text style="fontsize:48;fontname:Arial" x="880" y="3180">Stop 0.3s and Toggle switch</text>
        <text style="fontsize:48;fontname:Arial" x="952" y="796">50MHz</text>
        <text style="fontsize:48;fontname:Arial" x="3528" y="1588">Exchange MD1/MD2</text>
        <text style="fontsize:48;fontname:Arial" x="3528" y="1636">(Decimal Decoder)</text>
        <text style="fontsize:48;fontname:Arial" x="1336" y="548">PWM Base Cycle Generate (48.8kHz@50MHz CLK)</text>
        <instance x="2288" y="880" name="XLXI_126" orien="R0" />
        <text style="fontsize:48;fontname:Arial" x="1344" y="1156">PWM Duty Ratio Generate</text>
        <iomarker fontsize="28" x="1040" y="880" name="CLK" orien="R180" />
        <iomarker fontsize="28" x="480" y="1872" name="SW(7:0)" orien="R180" />
        <iomarker fontsize="28" x="432" y="2752" name="PSW0" orien="R180" />
        <iomarker fontsize="28" x="4064" y="2688" name="LED0" orien="R0" />
        <instance x="4608" y="2064" name="XLXI_78" orien="R0" />
        <branch name="MD2">
            <wire x2="4944" y1="2032" y2="2032" x1="4832" />
        </branch>
        <branch name="MD1">
            <wire x2="4944" y1="1840" y2="1840" x1="4832" />
        </branch>
        <instance x="4608" y="1872" name="XLXI_76" orien="R0" />
        <branch name="XLXN_171">
            <wire x2="4608" y1="1840" y2="1840" x1="4528" />
        </branch>
        <branch name="XLXN_172">
            <wire x2="4608" y1="2032" y2="2032" x1="4528" />
        </branch>
        <instance x="4272" y="1936" name="XLXI_124" orien="R0" />
        <instance x="4272" y="2128" name="XLXI_125" orien="R0" />
        <rect style="linecolor:rgb(0,0,255);linestyle:Dash" width="348" x="4184" y="1704" height="468" />
        <text style="fontsize:48;fontname:Arial" x="4220" y="1672">Output Inhibit</text>
        <iomarker fontsize="28" x="4944" y="2032" name="MD2" orien="R0" />
        <iomarker fontsize="28" x="4944" y="1840" name="MD1" orien="R0" />
        <branch name="XLXN_175">
            <wire x2="1440" y1="2688" y2="2688" x1="1360" />
            <wire x2="1600" y1="2688" y2="2688" x1="1440" />
            <wire x2="1440" y1="2448" y2="2688" x1="1440" />
            <wire x2="4224" y1="2448" y2="2448" x1="1440" />
            <wire x2="4272" y1="1872" y2="1872" x1="4224" />
            <wire x2="4224" y1="1872" y2="2064" x1="4224" />
            <wire x2="4272" y1="2064" y2="2064" x1="4224" />
            <wire x2="4224" y1="2064" y2="2448" x1="4224" />
        </branch>
        <instance x="3968" y="1840" name="XLXI_165" orien="R0" />
        <branch name="XLXN_174">
            <wire x2="3968" y1="1808" y2="1808" x1="3952" />
        </branch>
        <branch name="XLXN_330">
            <wire x2="4272" y1="1808" y2="1808" x1="4192" />
        </branch>
        <instance x="3968" y="2032" name="XLXI_166" orien="R0" />
        <branch name="XLXN_173">
            <wire x2="3968" y1="2000" y2="2000" x1="3952" />
        </branch>
        <branch name="XLXN_331">
            <wire x2="4272" y1="2000" y2="2000" x1="4192" />
        </branch>
        <text style="fontsize:48;fontname:Arial" x="532" y="408">with Reverse switch</text>
        <text style="fontsize:48;fontname:Arial" x="4640" y="1736">To the motor driver</text>
    </sheet>
</drawing>