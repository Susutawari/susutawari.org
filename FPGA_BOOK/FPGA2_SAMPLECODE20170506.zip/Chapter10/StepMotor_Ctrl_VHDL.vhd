library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity StepMotor_Ctrl_VHDL is

    port (
        CLK   : in  std_logic;
        PSW0  : in  std_logic;
        MD_A  : out std_logic;
        MD_B  : out std_logic;
        MD_C  : out std_logic;
        MD_D  : out std_logic;
        LED0  : out std_logic);

end StepMotor_Ctrl_VHDL;

architecture RTL of StepMotor_Ctrl_VHDL is

    signal rp_reg : std_logic_vector(17 downto 0);
    signal toggle_reg : std_logic;
    signal md_a_reg : std_logic;
    signal md_b_reg : std_logic;
    signal md_b_out : std_logic;

-- Stepping Motor Rotate Pulse Generate
begin

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (rp_reg(17)='1') then
            rp_reg <= "000000000000000000";
          else
            rp_reg <= rp_reg + '1';
          end if;
        end if;
    end process;

-- Stepping Pulse Waveform Generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (rp_reg(17)='1') then
            toggle_reg <= not toggle_reg;
            if (toggle_reg = '0') then
              md_a_reg <= not md_a_reg;
            else
              md_b_reg <= not md_b_reg;
            end if;
          end if;
        end if;
    end process;

    md_b_out <= md_b_reg xor PSW0;
    MD_A <= md_a_reg;
    MD_C <= not md_a_reg;
    MD_B <= md_b_out;
    MD_D <= not md_b_out;
    LED0 <= PSW0;

end RTL;
