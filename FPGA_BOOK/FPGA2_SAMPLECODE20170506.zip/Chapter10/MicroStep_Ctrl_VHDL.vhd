library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity MicroStep_Ctrl_VHDL is

    port (
        CLK   : in  std_logic;
        SW    : in  std_logic_vector(7 downto 0);
        PSW0  : in  std_logic;
        PSW1  : in  std_logic;
        PSW2  : in  std_logic;
        MD_A  : out std_logic;
        MD_B  : out std_logic;
        MD_C  : out std_logic;
        MD_D  : out std_logic;
        LED0  : out std_logic;
        LED1  : out std_logic);

end MicroStep_Ctrl_VHDL;

architecture RTL of MicroStep_Ctrl_VHDL is

    signal pwm_base_reg     : std_logic_vector(10 downto 0);
    signal pwmbp_reg        : std_logic;
    signal rpa_reg          : std_logic_vector(7 downto 0);
    signal sampc_reg        : std_logic_vector(20 downto 0);
    signal sw_reg           : std_logic_vector(7 downto 0);
    signal swd_reg          : std_logic_vector(7 downto 0);
    signal cyc_init_reg     : std_logic := '0';
    signal zero_a_reg       : std_logic;
    signal zero_b_reg       : std_logic;
    signal md_a_sel_reg     : std_logic;
    signal md_b_sel_reg     : std_logic;

    signal pwmbp            : std_logic;
    signal chat_filter_dout : std_logic;
    signal rpeq             : std_logic;
    signal rp               : std_logic;
    signal pwmout_a         : std_logic;
    signal pwmout_b         : std_logic;
    signal zero_a           : std_logic;
    signal zero_b           : std_logic;
    signal zero_a_pos       : std_logic;
    signal zero_b_pos       : std_logic;

    component CHAT_FILTER_VHDL
      port (
        CLK       : in  std_logic;
        CE        : in  std_logic;
        DIN       : in  std_logic;
        DOUT_ONE  : out std_logic
      );
    end component;

    component Trapezoid_PWM_GEN_VHDL
      port (
        CLK       : in  std_logic;
        PWMBP     : in  std_logic;
        D         : in  std_logic_vector(7 downto 0);
        L         : in  std_logic;
        CE        : in  std_logic;
        PWMOUT    : out std_logic;
        ZERO      : out std_logic
      );
    end component;

begin

-- PWM Base Cycle Generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (pwmbp = '1') then
            pwm_base_reg <= "00000000000";
          else
            pwm_base_reg <= pwm_base_reg + '1';
          end if;
        end if;
    end process;

    pwmbp <= pwm_base_reg(10);

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          pwmbp_reg <= pwmbp;
        end if;
    end process;

-- Rotate Pulse Generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (rpeq = '1') then
            rpa_reg <= X"00";
          elsif (pwmbp = '1') then
            rpa_reg <= rpa_reg + '1';
          end if;
        end if;
    end process;

-- Chat Filter
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (sampc_reg(20) = '1') then
            sampc_reg <= "000000000000000000000";
          else
            sampc_reg <= sampc_reg + '1';
          end if;
        end if;
    end process;

    CHAT_FILTER_VHDL_A : CHAT_FILTER_VHDL port map (
        CLK       =>  CLK,
        CE        =>  sampc_reg(20),
        DIN       =>  PSW2,
        DOUT_ONE  =>  chat_filter_dout
    );

-- Switch Input
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          sw_reg <= SW;
          swd_reg <= sw_reg;
        end if;
    end process;

    rpeq <= '1' when (rpa_reg = swd_reg) else '0';
    rp <= chat_filter_dout when (swd_reg = X"00") else rpeq;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          cyc_init_reg <= '1';
        end if;
    end process;

    Trapezoid_PWM_GEN_VHDL_A : Trapezoid_PWM_GEN_VHDL port map (
        CLK     =>  CLK,
        PWMBP   =>  pwmbp_reg,
        D       =>  X"00",
        L       =>  '0',
        CE      =>  rp,
        PWMOUT  =>  pwmout_a,
        ZERO    =>  zero_a
    );

    Trapezoid_PWM_GEN_VHDL_B : Trapezoid_PWM_GEN_VHDL port map (
        CLK     =>  CLK,
        PWMBP   =>  pwmbp_reg,
        D       =>  X"40",
        L       =>  not cyc_init_reg,
        CE      =>  rp,
        PWMOUT  =>  pwmout_b,
        ZERO    =>  zero_b
    );

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          zero_a_reg <= zero_a;
          zero_b_reg <= zero_b;
        end if;
    end process;

    zero_a_pos <= zero_a and not zero_a_reg;
    zero_b_pos <= zero_b and not zero_b_reg;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (zero_a_pos = '1') then
            md_a_sel_reg <= not md_a_sel_reg;
          end if;
          if (zero_b_pos = '1') then
            md_b_sel_reg <= not md_b_sel_reg;
          end if;
        end if;
    end process;

    MD_A <= not (pwmout_a and md_a_sel_reg) and not PSW1;
    MD_C <= not (pwmout_a and not md_a_sel_reg) and not PSW1;
    MD_B <= not (pwmout_b and (PSW0 xor md_b_sel_reg)) and not PSW1;
    MD_D <= not (pwmout_b and not (PSW0 xor md_b_sel_reg)) and not PSW1;

    LED0 <= PSW0;
    LED1 <= PSW1;

end RTL;
