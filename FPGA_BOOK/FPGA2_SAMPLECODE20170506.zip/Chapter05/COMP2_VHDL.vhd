library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity COMP2_VHDL is

    port (
        A  : in std_logic_vector(1 downto 0);
        B  : in std_logic_vector(1 downto 0);
        EQ : out std_logic);

end COMP2_VHDL;

architecture RTL of COMP2_VHDL is

begin

    EQ <= '1' when A = B else '0';

end RTL;
