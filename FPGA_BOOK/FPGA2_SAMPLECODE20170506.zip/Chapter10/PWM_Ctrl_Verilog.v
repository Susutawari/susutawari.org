module PWM_Ctrl_VERILOG(CLK, SW, MD1, MD2);

   input       CLK;
   input [7:0] SW;
   output      MD1;
   output      MD2;

   reg [7:0]   sw_reg_1d;
   reg [7:0]   sw_reg_2d;
   reg [10:0]  pwm_base_reg;
   reg [10:0]  pwm_duty_reg;
   reg         pwm_out_reg;
   
   wire   pwmbp;
   wire   pwm_out;

   /* Switch Input */
   always @(posedge CLK) begin
      sw_reg_1d <= SW;
      sw_reg_2d <= sw_reg_1d;
   end

   /* PWM Base Cycle Generate */
   always @(posedge CLK) begin
      if (pwmbp == 1'b1) begin
         pwm_base_reg <= 11'h000;
      end
      else begin
         pwm_base_reg <= pwm_base_reg + 1'b1;
      end
   end

   assign pwmbp = pwm_base_reg[10];

   /* PWM Duty Ratio Generate */
   always @(posedge CLK) begin
      if (pwmbp == 1'b1) begin
         pwm_duty_reg <= 11'h000;
      end
      else if (pwm_out == 1'b1) begin
         pwm_duty_reg <= pwm_duty_reg + 1'b1;
      end
   end

   assign pwm_out = (pwm_duty_reg[10:3] == sw_reg_2d) ? 1'b0 : 1'b1;

   /* To a motor driver */
   always @(posedge CLK) begin
      pwm_out_reg <= pwm_out;
   end

   assign MD1 = pwm_out_reg;
   assign MD2 = 1'b1;

endmodule
