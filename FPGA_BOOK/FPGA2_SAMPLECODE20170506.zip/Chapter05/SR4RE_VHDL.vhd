library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity SR4RE_VHDL is
    port (
        CLK : in  std_logic;
        CE  : in  std_logic;
        R   : in  std_logic;
        SLI : in  std_logic;
        Q0   : out std_logic;
        Q1   : out std_logic;
        Q2   : out std_logic;
        Q3   : out std_logic);
end SR4RE_VHDL;

architecture RTL of SR4RE_VHDL is

    signal Q_reg0 : std_logic;
    signal Q_reg1 : std_logic;
    signal Q_reg2 : std_logic;
    signal Q_reg3 : std_logic;

begin

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (R = '1') then
            Q_reg0 <= '0';
            Q_reg1 <= '0';
            Q_reg2 <= '0';
            Q_reg3 <= '0';
          elsif (CE = '1') then
            Q_reg0 <= SLI;
            Q_reg1 <= Q_reg0;
            Q_reg2 <= Q_reg1;
            Q_reg3 <= Q_reg2;
          end if;
        end if;
    end process;

    Q0 <= Q_reg0;
    Q1 <= Q_reg1;
    Q2 <= Q_reg2;
    Q3 <= Q_reg3;

end RTL;
