<?xml version="1.0" encoding="UTF-8"?>
<drawing version="7">
    <attr value="spartan3e" name="DeviceFamilyName">
        <trait delete="all:0" />
        <trait editname="all:0" />
        <trait edittrait="all:0" />
    </attr>
    <netlist>
        <signal name="XLXN_339" />
        <signal name="XLXN_300" />
        <signal name="PWMBP(17)" />
        <signal name="XLXN_284" />
        <signal name="LED0" />
        <signal name="PSW0" />
        <signal name="XLXN_439" />
        <signal name="MD_A" />
        <signal name="MD_C" />
        <signal name="XLXN_340" />
        <signal name="XLXN_342" />
        <signal name="MD_B" />
        <signal name="MD_D" />
        <signal name="XLXN_341" />
        <signal name="XLXN_596" />
        <signal name="XLXN_603" />
        <signal name="XLXN_604" />
        <signal name="CLK" />
        <signal name="XLXN_10" />
        <signal name="PWMBP(23:16)" />
        <signal name="XLXN_617" />
        <signal name="XLXN_619" />
        <signal name="XLXN_620" />
        <port polarity="Output" name="LED0" />
        <port polarity="Input" name="PSW0" />
        <port polarity="Output" name="MD_A" />
        <port polarity="Output" name="MD_C" />
        <port polarity="Output" name="MD_B" />
        <port polarity="Output" name="MD_D" />
        <port polarity="Input" name="CLK" />
        <blockdef name="cb16re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="320" y1="-128" y2="-128" x1="384" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="320" y1="-192" y2="-192" x1="384" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="ibufg">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
        </blockdef>
        <blockdef name="vcc">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-64" x1="64" />
            <line x2="64" y1="0" y2="-32" x1="64" />
            <line x2="32" y1="-64" y2="-64" x1="96" />
        </blockdef>
        <blockdef name="inv">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="160" y1="-32" y2="-32" x1="224" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="64" y1="0" y2="-64" x1="64" />
            <circle r="16" cx="144" cy="-32" />
        </blockdef>
        <blockdef name="gnd">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-96" x1="64" />
            <line x2="52" y1="-48" y2="-48" x1="76" />
            <line x2="60" y1="-32" y2="-32" x1="68" />
            <line x2="40" y1="-64" y2="-64" x1="88" />
            <line x2="64" y1="-64" y2="-80" x1="64" />
            <line x2="64" y1="-128" y2="-96" x1="64" />
        </blockdef>
        <blockdef name="obuf">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
        </blockdef>
        <blockdef name="ibuf">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
        </blockdef>
        <blockdef name="ftce">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="xor2">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="60" y1="-128" y2="-128" x1="0" />
            <line x2="208" y1="-96" y2="-96" x1="256" />
            <arc ex="44" ey="-144" sx="48" sy="-48" r="56" cx="16" cy="-96" />
            <arc ex="64" ey="-144" sx="64" sy="-48" r="56" cx="32" cy="-96" />
            <line x2="64" y1="-144" y2="-144" x1="128" />
            <line x2="64" y1="-48" y2="-48" x1="128" />
            <arc ex="128" ey="-144" sx="208" sy="-96" r="88" cx="132" cy="-56" />
            <arc ex="208" ey="-96" sx="128" sy="-48" r="88" cx="132" cy="-136" />
        </blockdef>
        <blockdef name="cb8re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="320" y1="-192" y2="-192" x1="384" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="320" y1="-128" y2="-128" x1="384" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <block symbolname="ftce" name="XLXI_131">
            <blockpin signalname="XLXN_619" name="C" />
            <blockpin signalname="PWMBP(17)" name="CE" />
            <blockpin signalname="XLXN_284" name="CLR" />
            <blockpin signalname="XLXN_596" name="T" />
            <blockpin signalname="XLXN_439" name="Q" />
        </block>
        <block symbolname="ftce" name="XLXI_130">
            <blockpin signalname="XLXN_619" name="C" />
            <blockpin signalname="PWMBP(17)" name="CE" />
            <blockpin signalname="XLXN_284" name="CLR" />
            <blockpin signalname="XLXN_620" name="T" />
            <blockpin signalname="XLXN_339" name="Q" />
        </block>
        <block symbolname="gnd" name="XLXI_132">
            <blockpin signalname="XLXN_284" name="G" />
        </block>
        <block symbolname="obuf" name="XLXI_118">
            <blockpin signalname="XLXN_300" name="I" />
            <blockpin signalname="LED0" name="O" />
        </block>
        <block symbolname="ibuf" name="XLXI_233">
            <blockpin signalname="PSW0" name="I" />
            <blockpin signalname="XLXN_300" name="O" />
        </block>
        <block symbolname="xor2" name="XLXI_145">
            <blockpin signalname="XLXN_300" name="I0" />
            <blockpin signalname="XLXN_439" name="I1" />
            <blockpin signalname="XLXN_341" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_76">
            <blockpin signalname="XLXN_339" name="I" />
            <blockpin signalname="MD_A" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_78">
            <blockpin signalname="XLXN_340" name="I" />
            <blockpin signalname="MD_C" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_147">
            <blockpin signalname="XLXN_339" name="I" />
            <blockpin signalname="XLXN_340" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_168">
            <blockpin signalname="XLXN_341" name="I" />
            <blockpin signalname="MD_B" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_169">
            <blockpin signalname="XLXN_342" name="I" />
            <blockpin signalname="MD_D" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_170">
            <blockpin signalname="XLXN_341" name="I" />
            <blockpin signalname="XLXN_342" name="O" />
        </block>
        <block symbolname="gnd" name="XLXI_324">
            <blockpin signalname="XLXN_603" name="G" />
        </block>
        <block symbolname="vcc" name="XLXI_330">
            <blockpin signalname="XLXN_604" name="P" />
        </block>
        <block symbolname="ftce" name="XLXI_332">
            <blockpin signalname="XLXN_619" name="C" />
            <blockpin signalname="PWMBP(17)" name="CE" />
            <blockpin signalname="XLXN_603" name="CLR" />
            <blockpin signalname="XLXN_604" name="T" />
            <blockpin signalname="XLXN_596" name="Q" />
        </block>
        <block symbolname="cb16re" name="XLXI_1">
            <blockpin signalname="XLXN_619" name="C" />
            <blockpin signalname="XLXN_10" name="CE" />
            <blockpin signalname="PWMBP(17)" name="R" />
            <blockpin signalname="XLXN_617" name="CEO" />
            <blockpin name="Q(15:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="ibufg" name="XLXI_5">
            <blockpin signalname="CLK" name="I" />
            <blockpin signalname="XLXN_619" name="O" />
        </block>
        <block symbolname="vcc" name="XLXI_6">
            <blockpin signalname="XLXN_10" name="P" />
        </block>
        <block symbolname="cb8re" name="XLXI_334">
            <blockpin signalname="XLXN_619" name="C" />
            <blockpin signalname="XLXN_617" name="CE" />
            <blockpin signalname="PWMBP(17)" name="R" />
            <blockpin name="CEO" />
            <blockpin signalname="PWMBP(23:16)" name="Q(7:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="inv" name="XLXI_339">
            <blockpin signalname="XLXN_596" name="I" />
            <blockpin signalname="XLXN_620" name="O" />
        </block>
    </netlist>
    <sheet sheetnum="1" width="5382" height="3801">
        <attr value="CM" name="LengthUnitName" />
        <attr value="4" name="GridsPerUnit" />
        <text style="fontsize:48;fontname:Arial" x="308" y="408">Stepping Motor Controller</text>
        <text style="fontsize:48;fontname:Arial" x="320" y="468">with reverse switch</text>
        <text style="fontsize:48;fontname:Arial" x="4024" y="2832">by Susutawari</text>
        <branch name="XLXN_284">
            <wire x2="3504" y1="1776" y2="1776" x1="3440" />
            <wire x2="3440" y1="1776" y2="2224" x1="3440" />
            <wire x2="3504" y1="2224" y2="2224" x1="3440" />
            <wire x2="3440" y1="2224" y2="2272" x1="3440" />
        </branch>
        <instance x="3504" y="2256" name="XLXI_131" orien="R0" />
        <instance x="3504" y="1808" name="XLXI_130" orien="R0" />
        <instance x="3376" y="2400" name="XLXI_132" orien="R0" />
        <instance x="4128" y="2544" name="XLXI_118" orien="R0" />
        <branch name="LED0">
            <wire x2="4416" y1="2512" y2="2512" x1="4352" />
        </branch>
        <instance x="3568" y="2544" name="XLXI_233" orien="R0" />
        <branch name="PSW0">
            <wire x2="3568" y1="2512" y2="2512" x1="3440" />
        </branch>
        <branch name="XLXN_439">
            <wire x2="4000" y1="2000" y2="2000" x1="3888" />
        </branch>
        <instance x="4000" y="2128" name="XLXI_145" orien="R0" />
        <branch name="XLXN_300">
            <wire x2="3952" y1="2512" y2="2512" x1="3792" />
            <wire x2="4128" y1="2512" y2="2512" x1="3952" />
            <wire x2="4000" y1="2064" y2="2064" x1="3952" />
            <wire x2="3952" y1="2064" y2="2512" x1="3952" />
        </branch>
        <branch name="MD_A">
            <wire x2="5008" y1="1552" y2="1552" x1="4928" />
        </branch>
        <branch name="MD_C">
            <wire x2="5008" y1="1728" y2="1728" x1="4928" />
        </branch>
        <branch name="XLXN_340">
            <wire x2="4704" y1="1728" y2="1728" x1="4640" />
        </branch>
        <branch name="XLXN_342">
            <wire x2="4704" y1="2208" y2="2208" x1="4640" />
        </branch>
        <branch name="MD_B">
            <wire x2="5008" y1="2032" y2="2032" x1="4928" />
        </branch>
        <branch name="MD_D">
            <wire x2="5008" y1="2208" y2="2208" x1="4928" />
        </branch>
        <branch name="XLXN_341">
            <wire x2="4352" y1="2032" y2="2032" x1="4256" />
            <wire x2="4352" y1="2032" y2="2208" x1="4352" />
            <wire x2="4416" y1="2208" y2="2208" x1="4352" />
            <wire x2="4704" y1="2032" y2="2032" x1="4352" />
        </branch>
        <instance x="4704" y="1584" name="XLXI_76" orien="R0" />
        <text style="fontsize:48;fontname:Arial" x="4768" y="1404">To a motor driver</text>
        <instance x="4704" y="1760" name="XLXI_78" orien="R0" />
        <instance x="4416" y="1760" name="XLXI_147" orien="R0" />
        <instance x="4704" y="2064" name="XLXI_168" orien="R0" />
        <instance x="4704" y="2240" name="XLXI_169" orien="R0" />
        <instance x="4416" y="2240" name="XLXI_170" orien="R0" />
        <iomarker fontsize="28" x="4416" y="2512" name="LED0" orien="R0" />
        <iomarker fontsize="28" x="3440" y="2512" name="PSW0" orien="R180" />
        <iomarker fontsize="28" x="5008" y="1552" name="MD_A" orien="R0" />
        <iomarker fontsize="28" x="5008" y="1728" name="MD_C" orien="R0" />
        <iomarker fontsize="28" x="5008" y="2032" name="MD_B" orien="R0" />
        <iomarker fontsize="28" x="5008" y="2208" name="MD_D" orien="R0" />
        <instance x="2464" y="1568" name="XLXI_324" orien="R0" />
        <branch name="XLXN_603">
            <wire x2="2560" y1="1392" y2="1392" x1="2528" />
            <wire x2="2528" y1="1392" y2="1440" x1="2528" />
        </branch>
        <instance x="2448" y="1136" name="XLXI_330" orien="R0" />
        <branch name="XLXN_604">
            <wire x2="2512" y1="1136" y2="1168" x1="2512" />
            <wire x2="2560" y1="1168" y2="1168" x1="2512" />
        </branch>
        <rect style="linewidth:W;linecolor:rgb(0,0,255);linestyle:Dash" width="1560" x="2344" y="968" height="1476" />
        <text style="fontsize:48;fontname:Arial" x="2380" y="932">Stepping Pulse Waveform Generate</text>
        <instance x="2560" y="1424" name="XLXI_332" orien="R0" />
        <instance x="800" y="1744" name="XLXI_1" orien="R0" />
        <instance x="352" y="1648" name="XLXI_5" orien="R0" />
        <branch name="CLK">
            <wire x2="352" y1="1616" y2="1616" x1="320" />
        </branch>
        <instance x="688" y="1504" name="XLXI_6" orien="R0" />
        <branch name="XLXN_10">
            <wire x2="752" y1="1504" y2="1552" x1="752" />
            <wire x2="800" y1="1552" y2="1552" x1="752" />
        </branch>
        <rect style="linewidth:W;linecolor:rgb(0,0,255);linestyle:Dash" width="1612" x="608" y="1320" height="568" />
        <text style="fontsize:48;fontname:Arial" x="624" y="1284">Stepping Motor Rotate Pulse Generate</text>
        <text style="fontsize:48;fontname:Arial" x="232" y="1532">50MHz</text>
        <instance x="1344" y="1744" name="XLXI_334" orien="R0" />
        <iomarker fontsize="28" x="320" y="1616" name="CLK" orien="R180" />
        <branch name="PWMBP(23:16)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="1856" y="1488" type="branch" />
            <wire x2="1856" y1="1488" y2="1488" x1="1728" />
            <wire x2="1856" y1="1488" y2="1616" x1="1856" />
        </branch>
        <bustap x2="1952" y1="1616" y2="1616" x1="1856" />
        <branch name="XLXN_617">
            <wire x2="1344" y1="1552" y2="1552" x1="1184" />
        </branch>
        <branch name="XLXN_619">
            <wire x2="672" y1="1616" y2="1616" x1="576" />
            <wire x2="800" y1="1616" y2="1616" x1="672" />
            <wire x2="672" y1="1616" y2="2128" x1="672" />
            <wire x2="1248" y1="2128" y2="2128" x1="672" />
            <wire x2="2464" y1="2128" y2="2128" x1="1248" />
            <wire x2="3312" y1="2128" y2="2128" x1="2464" />
            <wire x2="3504" y1="2128" y2="2128" x1="3312" />
            <wire x2="1344" y1="1616" y2="1616" x1="1248" />
            <wire x2="1248" y1="1616" y2="2128" x1="1248" />
            <wire x2="2560" y1="1296" y2="1296" x1="2464" />
            <wire x2="2464" y1="1296" y2="2128" x1="2464" />
            <wire x2="3504" y1="1680" y2="1680" x1="3312" />
            <wire x2="3312" y1="1680" y2="2128" x1="3312" />
        </branch>
        <text style="fontsize:32;fontname:Arial" x="1900" y="1556">381Hz@50MHz CLK</text>
        <branch name="XLXN_596">
            <wire x2="2976" y1="1168" y2="1168" x1="2944" />
            <wire x2="2976" y1="1168" y2="1552" x1="2976" />
            <wire x2="2976" y1="1552" y2="2000" x1="2976" />
            <wire x2="3504" y1="2000" y2="2000" x1="2976" />
            <wire x2="3056" y1="1552" y2="1552" x1="2976" />
        </branch>
        <instance x="3056" y="1584" name="XLXI_339" orien="R0" />
        <branch name="XLXN_620">
            <wire x2="3504" y1="1552" y2="1552" x1="3280" />
        </branch>
        <branch name="XLXN_339">
            <wire x2="4352" y1="1552" y2="1552" x1="3888" />
            <wire x2="4352" y1="1552" y2="1728" x1="4352" />
            <wire x2="4416" y1="1728" y2="1728" x1="4352" />
            <wire x2="4704" y1="1552" y2="1552" x1="4352" />
        </branch>
        <branch name="PWMBP(17)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2048" y="1616" type="branch" />
            <wire x2="800" y1="1712" y2="1712" x1="720" />
            <wire x2="720" y1="1712" y2="1808" x1="720" />
            <wire x2="1296" y1="1808" y2="1808" x1="720" />
            <wire x2="2080" y1="1808" y2="1808" x1="1296" />
            <wire x2="1344" y1="1712" y2="1712" x1="1296" />
            <wire x2="1296" y1="1712" y2="1808" x1="1296" />
            <wire x2="2048" y1="1616" y2="1616" x1="1952" />
            <wire x2="2080" y1="1616" y2="1616" x1="2048" />
            <wire x2="2080" y1="1616" y2="1808" x1="2080" />
            <wire x2="2400" y1="1616" y2="1616" x1="2080" />
            <wire x2="3376" y1="1616" y2="1616" x1="2400" />
            <wire x2="3504" y1="1616" y2="1616" x1="3376" />
            <wire x2="3376" y1="1616" y2="2064" x1="3376" />
            <wire x2="3504" y1="2064" y2="2064" x1="3376" />
            <wire x2="2560" y1="1232" y2="1232" x1="2400" />
            <wire x2="2400" y1="1232" y2="1616" x1="2400" />
        </branch>
    </sheet>
</drawing>