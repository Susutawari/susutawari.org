library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity PWM_Ctrl_VHDL is

    port (
        CLK   : in  std_logic;
        SW    : in  std_logic_vector(7 downto 0);
        MD1   : out std_logic;
        MD2   : out std_logic);

end PWM_Ctrl_VHDL;

architecture RTL of PWM_Ctrl_VHDL is

    signal sw_reg_1d    : std_logic_vector(7 downto 0);
    signal sw_reg_2d    : std_logic_vector(7 downto 0);
    signal pwm_base_reg : std_logic_vector(10 downto 0);
    signal pwm_duty_reg : std_logic_vector(10 downto 0);
    signal pwm_out      : std_logic;
    signal pwm_out_reg  : std_logic;
    signal pwmbp        : std_logic;

-- Switch Input
begin

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          sw_reg_1d <= SW;
          sw_reg_2d <= sw_reg_1d;
        end if;
    end process;

-- PWM Base Cycle Generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (pwmbp = '1') then
            pwm_base_reg <= "00000000000";
          else
            pwm_base_reg <= pwm_base_reg + '1';
          end if;
        end if;
    end process;

    pwmbp <= pwm_base_reg(10);

-- PWM Duty Ratio Generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (pwmbp = '1') then
            pwm_duty_reg <= "00000000000";
          elsif (pwm_out = '1') then
            pwm_duty_reg <= pwm_duty_reg + '1';
          end if;
        end if;
    end process;

    pwm_out <= '0' when pwm_duty_reg(10 downto 3) = sw_reg_2d else '1';

-- To a motor driver
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          pwm_out_reg <= pwm_out;
        end if;
    end process;

    MD1 <= pwm_out_reg;
    MD2 <= '1';

end RTL;
