<?xml version="1.0" encoding="UTF-8"?>
<drawing version="7">
    <attr value="spartan3e" name="DeviceFamilyName">
        <trait delete="all:0" />
        <trait editname="all:0" />
        <trait edittrait="all:0" />
    </attr>
    <netlist>
        <signal name="XLXN_5" />
        <signal name="XLXN_6" />
        <signal name="XLXN_7" />
        <signal name="XLXN_8" />
        <signal name="XLXN_9" />
        <signal name="XLXN_10" />
        <signal name="XLXN_11" />
        <signal name="XLXN_12" />
        <signal name="XLXN_15" />
        <signal name="XLXN_16" />
        <signal name="XLXN_20" />
        <signal name="A1" />
        <signal name="B1" />
        <signal name="A0" />
        <signal name="B0" />
        <signal name="XLXN_17" />
        <signal name="XLXN_18" />
        <signal name="XLXN_19" />
        <signal name="XLXN_21" />
        <signal name="XLXN_22" />
        <signal name="XLXN_23" />
        <signal name="XLXN_24" />
        <signal name="GT" />
        <signal name="LT" />
        <port polarity="Input" name="A1" />
        <port polarity="Input" name="B1" />
        <port polarity="Input" name="A0" />
        <port polarity="Input" name="B0" />
        <port polarity="Output" name="GT" />
        <port polarity="Output" name="LT" />
        <blockdef name="xnor2">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="60" y1="-128" y2="-128" x1="0" />
            <arc ex="44" ey="-144" sx="48" sy="-48" r="56" cx="16" cy="-96" />
            <arc ex="64" ey="-144" sx="64" sy="-48" r="56" cx="32" cy="-96" />
            <line x2="64" y1="-144" y2="-144" x1="128" />
            <line x2="64" y1="-48" y2="-48" x1="128" />
            <arc ex="128" ey="-144" sx="208" sy="-96" r="88" cx="132" cy="-56" />
            <arc ex="208" ey="-96" sx="128" sy="-48" r="88" cx="132" cy="-136" />
            <circle r="8" cx="220" cy="-96" />
            <line x2="256" y1="-96" y2="-96" x1="228" />
            <line x2="60" y1="-28" y2="-28" x1="60" />
        </blockdef>
        <blockdef name="and2">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="192" y1="-96" y2="-96" x1="256" />
            <arc ex="144" ey="-144" sx="144" sy="-48" r="48" cx="144" cy="-96" />
            <line x2="64" y1="-48" y2="-48" x1="144" />
            <line x2="144" y1="-144" y2="-144" x1="64" />
            <line x2="64" y1="-48" y2="-144" x1="64" />
        </blockdef>
        <blockdef name="and2b1">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-48" y2="-144" x1="64" />
            <line x2="144" y1="-144" y2="-144" x1="64" />
            <line x2="64" y1="-48" y2="-48" x1="144" />
            <arc ex="144" ey="-144" sx="144" sy="-48" r="48" cx="144" cy="-96" />
            <line x2="192" y1="-96" y2="-96" x1="256" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="40" y1="-64" y2="-64" x1="0" />
            <circle r="12" cx="52" cy="-64" />
        </blockdef>
        <blockdef name="or2">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="192" y1="-96" y2="-96" x1="256" />
            <arc ex="192" ey="-96" sx="112" sy="-48" r="88" cx="116" cy="-136" />
            <arc ex="48" ey="-144" sx="48" sy="-48" r="56" cx="16" cy="-96" />
            <line x2="48" y1="-144" y2="-144" x1="112" />
            <arc ex="112" ey="-144" sx="192" sy="-96" r="88" cx="116" cy="-56" />
            <line x2="48" y1="-48" y2="-48" x1="112" />
        </blockdef>
        <block symbolname="and2b1" name="XLXI_6">
            <blockpin signalname="B1" name="I0" />
            <blockpin signalname="A1" name="I1" />
            <blockpin signalname="XLXN_23" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_7">
            <blockpin signalname="A1" name="I0" />
            <blockpin signalname="B1" name="I1" />
            <blockpin signalname="XLXN_24" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_8">
            <blockpin signalname="B0" name="I0" />
            <blockpin signalname="A0" name="I1" />
            <blockpin signalname="XLXN_17" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_9">
            <blockpin signalname="A0" name="I0" />
            <blockpin signalname="B0" name="I1" />
            <blockpin signalname="XLXN_18" name="O" />
        </block>
        <block symbolname="xnor2" name="XLXI_10">
            <blockpin signalname="A1" name="I0" />
            <blockpin signalname="B1" name="I1" />
            <blockpin signalname="XLXN_19" name="O" />
        </block>
        <block symbolname="and2" name="XLXI_11">
            <blockpin signalname="XLXN_19" name="I0" />
            <blockpin signalname="XLXN_17" name="I1" />
            <blockpin signalname="XLXN_21" name="O" />
        </block>
        <block symbolname="and2" name="XLXI_12">
            <blockpin signalname="XLXN_19" name="I0" />
            <blockpin signalname="XLXN_18" name="I1" />
            <blockpin signalname="XLXN_22" name="O" />
        </block>
        <block symbolname="or2" name="XLXI_13">
            <blockpin signalname="XLXN_21" name="I0" />
            <blockpin signalname="XLXN_23" name="I1" />
            <blockpin signalname="GT" name="O" />
        </block>
        <block symbolname="or2" name="XLXI_14">
            <blockpin signalname="XLXN_22" name="I0" />
            <blockpin signalname="XLXN_24" name="I1" />
            <blockpin signalname="LT" name="O" />
        </block>
    </netlist>
    <sheet sheetnum="1" width="1760" height="1360">
        <text style="fontsize:48;fontname:Arial" x="76" y="92">COMPM2_SCH</text>
        <text style="fontsize:32;fontname:Arial" x="1352" y="1240">by Susutawari</text>
        <instance x="576" y="352" name="XLXI_6" orien="R0" />
        <instance x="576" y="528" name="XLXI_7" orien="R0" />
        <instance x="576" y="912" name="XLXI_8" orien="R0" />
        <instance x="576" y="1088" name="XLXI_9" orien="R0" />
        <branch name="A1">
            <wire x2="336" y1="224" y2="224" x1="208" />
            <wire x2="336" y1="224" y2="464" x1="336" />
            <wire x2="576" y1="464" y2="464" x1="336" />
            <wire x2="336" y1="464" y2="656" x1="336" />
            <wire x2="576" y1="656" y2="656" x1="336" />
            <wire x2="576" y1="224" y2="224" x1="336" />
        </branch>
        <branch name="B1">
            <wire x2="400" y1="288" y2="288" x1="208" />
            <wire x2="400" y1="288" y2="400" x1="400" />
            <wire x2="576" y1="400" y2="400" x1="400" />
            <wire x2="400" y1="400" y2="592" x1="400" />
            <wire x2="576" y1="592" y2="592" x1="400" />
            <wire x2="576" y1="288" y2="288" x1="400" />
        </branch>
        <instance x="576" y="720" name="XLXI_10" orien="R0" />
        <branch name="A0">
            <wire x2="336" y1="784" y2="784" x1="208" />
            <wire x2="336" y1="784" y2="1024" x1="336" />
            <wire x2="576" y1="1024" y2="1024" x1="336" />
            <wire x2="576" y1="784" y2="784" x1="336" />
        </branch>
        <branch name="B0">
            <wire x2="400" y1="848" y2="848" x1="208" />
            <wire x2="400" y1="848" y2="960" x1="400" />
            <wire x2="576" y1="960" y2="960" x1="400" />
            <wire x2="576" y1="848" y2="848" x1="400" />
        </branch>
        <instance x="960" y="944" name="XLXI_11" orien="R0" />
        <instance x="960" y="1120" name="XLXI_12" orien="R0" />
        <branch name="XLXN_17">
            <wire x2="960" y1="816" y2="816" x1="832" />
        </branch>
        <branch name="XLXN_18">
            <wire x2="960" y1="992" y2="992" x1="832" />
        </branch>
        <branch name="XLXN_19">
            <wire x2="896" y1="624" y2="624" x1="832" />
            <wire x2="896" y1="624" y2="880" x1="896" />
            <wire x2="960" y1="880" y2="880" x1="896" />
            <wire x2="896" y1="880" y2="1056" x1="896" />
            <wire x2="960" y1="1056" y2="1056" x1="896" />
        </branch>
        <instance x="1344" y="912" name="XLXI_13" orien="R0" />
        <instance x="1344" y="1088" name="XLXI_14" orien="R0" />
        <branch name="XLXN_21">
            <wire x2="1344" y1="848" y2="848" x1="1216" />
        </branch>
        <branch name="XLXN_22">
            <wire x2="1344" y1="1024" y2="1024" x1="1216" />
        </branch>
        <branch name="XLXN_23">
            <wire x2="1312" y1="256" y2="256" x1="832" />
            <wire x2="1312" y1="256" y2="784" x1="1312" />
            <wire x2="1344" y1="784" y2="784" x1="1312" />
        </branch>
        <branch name="XLXN_24">
            <wire x2="1264" y1="432" y2="432" x1="832" />
            <wire x2="1264" y1="432" y2="960" x1="1264" />
            <wire x2="1344" y1="960" y2="960" x1="1264" />
        </branch>
        <iomarker fontsize="28" x="208" y="224" name="A1" orien="R180" />
        <iomarker fontsize="28" x="208" y="288" name="B1" orien="R180" />
        <iomarker fontsize="28" x="208" y="784" name="A0" orien="R180" />
        <iomarker fontsize="28" x="208" y="848" name="B0" orien="R180" />
        <branch name="GT">
            <wire x2="1632" y1="816" y2="816" x1="1600" />
        </branch>
        <iomarker fontsize="28" x="1632" y="816" name="GT" orien="R0" />
        <branch name="LT">
            <wire x2="1632" y1="992" y2="992" x1="1600" />
        </branch>
        <iomarker fontsize="28" x="1632" y="992" name="LT" orien="R0" />
    </sheet>
</drawing>