module Trapezoid_PWM_GEN_Verilog(CLK, PWMBP, D, L, CE, PWMOUT, ZERO);

   input       CLK;
   input       PWMBP;
   input [7:0] D;
   input       L;
   input       CE;
   output      PWMOUT;
   output      ZERO;

   reg [10:0]  pwmd_reg;
   reg [7:0]   tw_reg;
   reg         pwmout_reg;
   reg         tw_up_reg  = 1'b1;
   reg [7:0]   fl_reg;
   reg         tw7_reg;
   reg         ge128_reg;

   wire        neq;
   wire        tw_en;
   wire        tw7_pos;
   wire        ge128;
   wire        fl_en;

   /* PWM duty ratio counter */
   always @(posedge CLK) begin
      if (PWMBP == 1'b1) begin
         pwmd_reg <= 11'h000;
      end
      else if (neq == 1'b1) begin
         pwmd_reg <= pwmd_reg + 1'b1;
      end
   end

   /* Up down counter */
   always @(posedge CLK) begin
      if (L == 1'b1) begin
         tw_reg <= D;
      end
      else if (tw_en == 1'b1) begin
         if (tw_up_reg == 1'b1) begin
            tw_reg <= tw_reg + 1'b1;
         end
         else begin
            tw_reg <= tw_reg - 1'b1;
         end
      end
   end

   always @(posedge CLK) begin
      pwmout_reg <= neq;
   end

   always @(posedge CLK) begin
      if (fl_reg[7] == 1'b1) begin
         tw_up_reg <= 1'b0;
      end
      else if (tw_reg == 8'h00) begin
         tw_up_reg <= 1'b1;
      end
   end

   assign tw_en = CE & ~ge128;
   assign neq = (pwmd_reg[10:3] == tw_reg) ? 1'b0 : 1'b1;

   assign PWMOUT = pwmout_reg;
   assign ZERO = (tw_reg == 8'h00) ? 1'b1 : 1'b0;

   /* Positive edge detection of tw_reg[7] */
   always @(posedge CLK) begin
      tw7_reg <= tw_reg[7];
   end

   assign tw7_pos = tw_reg[7] & (~tw7_reg);

   always @(posedge CLK) begin
      if (fl_reg[7] == 1'b1) begin
         ge128_reg <= 1'b0;
      end
      else if (tw7_pos == 1'b1) begin
         ge128_reg <= 1'b1;
      end
   end

   assign ge128 = tw7_pos | ge128_reg;
   assign fl_en = ge128 & CE;

   always @(posedge CLK) begin
      if (fl_reg[7] == 1'b1) begin
         fl_reg <= 8'h00;
      end
      else if (fl_en == 1'b1) begin
         fl_reg <= fl_reg + 1'b1;
      end
   end

endmodule
