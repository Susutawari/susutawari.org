library IEEE;
use IEEE.std_logic_1164.all;

entity FDE_VHDL is
    
    port (
        CLK  : in  std_logic;
        CE  : in  std_logic;
        D  : in  std_logic;
        Q : out std_logic);

end FDE_VHDL;

architecture RTL of FDE_VHDL is

    signal Q_reg : std_logic;

begin

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (CE = '1') then
                Q_reg <= D;                
            end if;
        end if;
    end process;

    Q <= Q_reg;

end RTL;
