library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity Trapezoid_PWM_GEN_VHDL is

    port (
        CLK   : in  std_logic;
        PWMBP : in  std_logic;
        D     : in  std_logic_vector(7 downto 0);
        L     : in  std_logic;
        CE    : in  std_logic;
        PWMOUT: out std_logic;
        ZERO  : out std_logic);

end Trapezoid_PWM_GEN_VHDL;

architecture RTL of Trapezoid_PWM_GEN_VHDL is

    signal pwmd_reg    : std_logic_vector(10 downto 0);
    signal tw_reg      : std_logic_vector(7 downto 0);
    signal pwm_out_reg : std_logic;
    signal tw_up_reg   : std_logic := '1';
    signal fl_reg      : std_logic_vector(7 downto 0);
    signal tw7_reg     : std_logic;
    signal ge128_reg   : std_logic;

    signal neq         : std_logic;
    signal tw_en       : std_logic;
    signal tw7_pos     : std_logic;
    signal ge128       : std_logic;
    signal fl_en       : std_logic;

begin
-- PWM Duty Ratio Generate
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (PWMBP = '1') then
            pwmd_reg <= "00000000000";
          elsif (neq = '1') then
            pwmd_reg <= pwmd_reg + '1';
          end if;
        end if;
    end process;

-- Up down counter
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (L = '1') then
            tw_reg <= D;
          elsif (tw_en = '1') then
            if (tw_up_reg = '1') then
              tw_reg <= tw_reg + '1';
            else
              tw_reg <= tw_reg - '1';
            end if;
          end if;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          pwm_out_reg <= neq;
        end if;
    end process;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (fl_reg(7) = '1') then
            tw_up_reg <= '0';
          elsif (tw_reg = X"00") then
            tw_up_reg <= '1';
          end if;
        end if;
    end process;

    tw_en <= CE and not ge128;
    neq <= '0' when (pwmd_reg(10 downto 3) = tw_reg) else '1';

    PWMOUT <= pwm_out_reg;
    ZERO <= '1' when (tw_reg = X"00") else '0';

-- Positive edge detection of tw_reg(7)
    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          tw7_reg <= tw_reg(7);
        end if;
    end process;

    tw7_pos <= tw_reg(7) and not tw7_reg;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (fl_reg(7) = '1') then
            ge128_reg <= '0';
          elsif (tw7_pos = '1') then
            ge128_reg <= '1';
          end if;
        end if;
    end process;

    ge128 <= tw7_pos or ge128_reg;
    fl_en <= ge128 and CE;

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
          if (fl_reg(7) = '1') then
            fl_reg <= X"00";
          elsif (fl_en = '1') then
            fl_reg <= fl_reg + '1';
          end if;
        end if;
    end process;

end RTL;
