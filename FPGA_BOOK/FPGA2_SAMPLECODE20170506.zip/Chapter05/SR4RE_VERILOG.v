module SR4RE_VERILOG(CLK, R, CE, SLI, Q0, Q1, Q2, Q3);

   input  CLK;
   input  R;
   input  CE;
   input  SLI;
   output Q0;
   output Q1;
   output Q2;
   output Q3;

   reg    Q0;
   reg    Q1;
   reg    Q2;
   reg    Q3;

   always @(posedge CLK) begin
      if (R == 1'b1) begin
         Q0 <= 1'b0;
         Q1 <= 1'b0;
         Q2 <= 1'b0;
         Q3 <= 1'b0;
      end
      else if (CE == 1'b1) begin
         Q0 <= SLI;
         Q1 <= Q0;
         Q2 <= Q1;
         Q3 <= Q2;
      end
   end

endmodule
