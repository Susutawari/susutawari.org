<?xml version="1.0" encoding="UTF-8"?>
<drawing version="7">
    <attr value="spartan3e" name="DeviceFamilyName">
        <trait delete="all:0" />
        <trait editname="all:0" />
        <trait edittrait="all:0" />
    </attr>
    <netlist>
        <signal name="XLXN_1" />
        <signal name="XLXN_2" />
        <signal name="A0" />
        <signal name="B0" />
        <signal name="A1" />
        <signal name="B1" />
        <signal name="EQ" />
        <port polarity="Input" name="A0" />
        <port polarity="Input" name="B0" />
        <port polarity="Input" name="A1" />
        <port polarity="Input" name="B1" />
        <port polarity="Output" name="EQ" />
        <blockdef name="xnor2">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="60" y1="-128" y2="-128" x1="0" />
            <arc ex="44" ey="-144" sx="48" sy="-48" r="56" cx="16" cy="-96" />
            <arc ex="64" ey="-144" sx="64" sy="-48" r="56" cx="32" cy="-96" />
            <line x2="64" y1="-144" y2="-144" x1="128" />
            <line x2="64" y1="-48" y2="-48" x1="128" />
            <arc ex="128" ey="-144" sx="208" sy="-96" r="88" cx="132" cy="-56" />
            <arc ex="208" ey="-96" sx="128" sy="-48" r="88" cx="132" cy="-136" />
            <circle r="8" cx="220" cy="-96" />
            <line x2="256" y1="-96" y2="-96" x1="228" />
            <line x2="60" y1="-28" y2="-28" x1="60" />
        </blockdef>
        <blockdef name="and2">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="192" y1="-96" y2="-96" x1="256" />
            <arc ex="144" ey="-144" sx="144" sy="-48" r="48" cx="144" cy="-96" />
            <line x2="64" y1="-48" y2="-48" x1="144" />
            <line x2="144" y1="-144" y2="-144" x1="64" />
            <line x2="64" y1="-48" y2="-144" x1="64" />
        </blockdef>
        <block symbolname="xnor2" name="XLXI_2">
            <blockpin signalname="B0" name="I0" />
            <blockpin signalname="A0" name="I1" />
            <blockpin signalname="XLXN_1" name="O" />
        </block>
        <block symbolname="and2" name="XLXI_4">
            <blockpin signalname="XLXN_2" name="I0" />
            <blockpin signalname="XLXN_1" name="I1" />
            <blockpin signalname="EQ" name="O" />
        </block>
        <block symbolname="xnor2" name="XLXI_3">
            <blockpin signalname="B1" name="I0" />
            <blockpin signalname="A1" name="I1" />
            <blockpin signalname="XLXN_2" name="O" />
        </block>
    </netlist>
    <sheet sheetnum="1" width="1760" height="1360">
        <instance x="576" y="624" name="XLXI_2" orien="R0" />
        <instance x="944" y="736" name="XLXI_4" orien="R0" />
        <branch name="XLXN_1">
            <wire x2="880" y1="528" y2="528" x1="832" />
            <wire x2="880" y1="528" y2="608" x1="880" />
            <wire x2="944" y1="608" y2="608" x1="880" />
        </branch>
        <branch name="XLXN_2">
            <wire x2="880" y1="752" y2="752" x1="832" />
            <wire x2="880" y1="672" y2="752" x1="880" />
            <wire x2="944" y1="672" y2="672" x1="880" />
        </branch>
        <instance x="576" y="848" name="XLXI_3" orien="R0" />
        <branch name="A0">
            <wire x2="576" y1="496" y2="496" x1="544" />
        </branch>
        <branch name="B0">
            <wire x2="576" y1="560" y2="560" x1="544" />
        </branch>
        <branch name="A1">
            <wire x2="576" y1="720" y2="720" x1="544" />
        </branch>
        <branch name="B1">
            <wire x2="576" y1="784" y2="784" x1="544" />
        </branch>
        <branch name="EQ">
            <wire x2="1232" y1="640" y2="640" x1="1200" />
        </branch>
        <iomarker fontsize="28" x="544" y="496" name="A0" orien="R180" />
        <iomarker fontsize="28" x="544" y="560" name="B0" orien="R180" />
        <iomarker fontsize="28" x="544" y="720" name="A1" orien="R180" />
        <iomarker fontsize="28" x="544" y="784" name="B1" orien="R180" />
        <iomarker fontsize="28" x="1232" y="640" name="EQ" orien="R0" />
        <text style="fontsize:32;fontname:Arial" x="1312" y="1092">by Susutawari</text>
        <text style="fontsize:48;fontname:Arial" x="136" y="228">COMP2_SCH</text>
    </sheet>
</drawing>