module StepMotor_Ctrl_Verilog(CLK, PSW0, MD_A, MD_B, MD_C, MD_D, LED0);

   input  CLK;
   input  PSW0;
   output MD_A;
   output MD_B;
   output MD_C;
   output MD_D;
   output LED0;

   reg [17:0] rpa_reg;
   reg        toggle_reg;
   reg        md_a_reg;
   reg        md_b_reg;

   wire       md_b_out;

   /* Stepping Motor Rotate Pulse Generate */
   always @(posedge CLK) begin
      if (rpa_reg[17] == 1'b1) begin
         rpa_reg <= 18'h00000;
      end
      else begin
         rpa_reg <= rpa_reg + 1'b1;
      end
   end

   /* Stepping Pulse Waveform Generate */
   always @(posedge CLK) begin
      if (rpa_reg[17] == 1'b1) begin
         toggle_reg <= ~toggle_reg;
         if (toggle_reg == 1'b0) begin
            md_a_reg <= ~md_a_reg;
         end
         else begin
            md_b_reg <= ~md_b_reg;
         end
      end
   end

   assign md_b_out = md_b_reg ^ PSW0;

   assign MD_A =  md_a_reg;
   assign MD_C = ~md_a_reg;
   assign MD_B =  md_b_out;
   assign MD_D = ~md_b_out;
   assign LED0 =  PSW0;

endmodule
