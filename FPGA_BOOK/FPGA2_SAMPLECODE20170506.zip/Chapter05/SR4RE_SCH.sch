<?xml version="1.0" encoding="UTF-8"?>
<drawing version="7">
    <attr value="spartan3e" name="DeviceFamilyName">
        <trait delete="all:0" />
        <trait editname="all:0" />
        <trait edittrait="all:0" />
    </attr>
    <netlist>
        <signal name="XLXN_2" />
        <signal name="XLXN_3" />
        <signal name="XLXN_5" />
        <signal name="XLXN_6" />
        <signal name="XLXN_8" />
        <signal name="XLXN_9" />
        <signal name="XLXN_10" />
        <signal name="XLXN_11" />
        <signal name="XLXN_12" />
        <signal name="XLXN_13" />
        <signal name="XLXN_14" />
        <signal name="XLXN_15" />
        <signal name="XLXN_16" />
        <signal name="XLXN_17" />
        <signal name="XLXN_18" />
        <signal name="XLXN_24" />
        <signal name="R" />
        <signal name="XLXN_26" />
        <signal name="CLK" />
        <signal name="XLXN_28" />
        <signal name="CE" />
        <signal name="XLXN_30" />
        <signal name="Q0" />
        <signal name="XLXN_32" />
        <signal name="Q1" />
        <signal name="XLXN_34" />
        <signal name="Q2" />
        <signal name="SLI" />
        <signal name="Q3" />
        <port polarity="Input" name="R" />
        <port polarity="Input" name="CLK" />
        <port polarity="Input" name="CE" />
        <port polarity="Output" name="Q0" />
        <port polarity="Output" name="Q1" />
        <port polarity="Output" name="Q2" />
        <port polarity="Input" name="SLI" />
        <port polarity="Output" name="Q3" />
        <blockdef name="fdre">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <rect width="256" x="64" y="-320" height="256" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
        </blockdef>
        <block symbolname="fdre" name="XLXI_5">
            <blockpin signalname="CLK" name="C" />
            <blockpin signalname="CE" name="CE" />
            <blockpin signalname="Q2" name="D" />
            <blockpin signalname="R" name="R" />
            <blockpin signalname="Q3" name="Q" />
        </block>
        <block symbolname="fdre" name="XLXI_4">
            <blockpin signalname="CLK" name="C" />
            <blockpin signalname="CE" name="CE" />
            <blockpin signalname="Q1" name="D" />
            <blockpin signalname="R" name="R" />
            <blockpin signalname="Q2" name="Q" />
        </block>
        <block symbolname="fdre" name="XLXI_3">
            <blockpin signalname="CLK" name="C" />
            <blockpin signalname="CE" name="CE" />
            <blockpin signalname="Q0" name="D" />
            <blockpin signalname="R" name="R" />
            <blockpin signalname="Q1" name="Q" />
        </block>
        <block symbolname="fdre" name="XLXI_2">
            <blockpin signalname="CLK" name="C" />
            <blockpin signalname="CE" name="CE" />
            <blockpin signalname="SLI" name="D" />
            <blockpin signalname="R" name="R" />
            <blockpin signalname="Q0" name="Q" />
        </block>
    </netlist>
    <sheet sheetnum="1" width="3520" height="2720">
        <instance x="1568" y="2192" name="XLXI_5" orien="R0" />
        <branch name="R">
            <wire x2="1456" y1="2160" y2="2160" x1="992" />
            <wire x2="1568" y1="2160" y2="2160" x1="1456" />
            <wire x2="1456" y1="752" y2="1216" x1="1456" />
            <wire x2="1456" y1="1216" y2="1680" x1="1456" />
            <wire x2="1456" y1="1680" y2="2160" x1="1456" />
            <wire x2="1568" y1="1680" y2="1680" x1="1456" />
            <wire x2="1568" y1="1216" y2="1216" x1="1456" />
            <wire x2="1568" y1="752" y2="752" x1="1456" />
        </branch>
        <branch name="CLK">
            <wire x2="1392" y1="2064" y2="2064" x1="992" />
            <wire x2="1568" y1="2064" y2="2064" x1="1392" />
            <wire x2="1392" y1="656" y2="1120" x1="1392" />
            <wire x2="1392" y1="1120" y2="1584" x1="1392" />
            <wire x2="1392" y1="1584" y2="2064" x1="1392" />
            <wire x2="1568" y1="1584" y2="1584" x1="1392" />
            <wire x2="1568" y1="1120" y2="1120" x1="1392" />
            <wire x2="1568" y1="656" y2="656" x1="1392" />
        </branch>
        <branch name="CE">
            <wire x2="1344" y1="2000" y2="2000" x1="992" />
            <wire x2="1568" y1="2000" y2="2000" x1="1344" />
            <wire x2="1344" y1="592" y2="1056" x1="1344" />
            <wire x2="1344" y1="1056" y2="1520" x1="1344" />
            <wire x2="1344" y1="1520" y2="2000" x1="1344" />
            <wire x2="1568" y1="1520" y2="1520" x1="1344" />
            <wire x2="1568" y1="1056" y2="1056" x1="1344" />
            <wire x2="1568" y1="592" y2="592" x1="1344" />
        </branch>
        <instance x="1568" y="1712" name="XLXI_4" orien="R0" />
        <instance x="1568" y="1248" name="XLXI_3" orien="R0" />
        <instance x="1568" y="784" name="XLXI_2" orien="R0" />
        <branch name="Q0">
            <wire x2="2032" y1="832" y2="832" x1="1520" />
            <wire x2="1520" y1="832" y2="992" x1="1520" />
            <wire x2="1568" y1="992" y2="992" x1="1520" />
            <wire x2="2032" y1="528" y2="528" x1="1952" />
            <wire x2="2032" y1="528" y2="832" x1="2032" />
            <wire x2="2304" y1="528" y2="528" x1="2032" />
        </branch>
        <branch name="Q1">
            <wire x2="2032" y1="1280" y2="1280" x1="1520" />
            <wire x2="1520" y1="1280" y2="1456" x1="1520" />
            <wire x2="1568" y1="1456" y2="1456" x1="1520" />
            <wire x2="2032" y1="992" y2="992" x1="1952" />
            <wire x2="2032" y1="992" y2="1280" x1="2032" />
            <wire x2="2304" y1="992" y2="992" x1="2032" />
        </branch>
        <branch name="Q2">
            <wire x2="2032" y1="1760" y2="1760" x1="1520" />
            <wire x2="1520" y1="1760" y2="1936" x1="1520" />
            <wire x2="1568" y1="1936" y2="1936" x1="1520" />
            <wire x2="2032" y1="1456" y2="1456" x1="1952" />
            <wire x2="2032" y1="1456" y2="1760" x1="2032" />
            <wire x2="2304" y1="1456" y2="1456" x1="2032" />
        </branch>
        <branch name="SLI">
            <wire x2="1568" y1="528" y2="528" x1="992" />
        </branch>
        <branch name="Q3">
            <wire x2="2304" y1="1936" y2="1936" x1="1952" />
        </branch>
        <iomarker fontsize="28" x="992" y="2064" name="CLK" orien="R180" />
        <iomarker fontsize="28" x="992" y="2160" name="R" orien="R180" />
        <iomarker fontsize="28" x="992" y="2000" name="CE" orien="R180" />
        <iomarker fontsize="28" x="992" y="528" name="SLI" orien="R180" />
        <iomarker fontsize="28" x="2304" y="528" name="Q0" orien="R0" />
        <iomarker fontsize="28" x="2304" y="992" name="Q1" orien="R0" />
        <iomarker fontsize="28" x="2304" y="1456" name="Q2" orien="R0" />
        <iomarker fontsize="28" x="2304" y="1936" name="Q3" orien="R0" />
        <text style="fontsize:32;fontname:Arial" x="2488" y="2316">by Susutawari</text>
        <text style="fontsize:48;fontname:Arial" x="300" y="280">SR4RE_SCH</text>
    </sheet>
</drawing>