<?xml version="1.0" encoding="UTF-8"?>
<drawing version="7">
    <attr value="spartan3e" name="DeviceFamilyName">
        <trait delete="all:0" />
        <trait editname="all:0" />
        <trait edittrait="all:0" />
    </attr>
    <netlist>
        <signal name="PWM_BASE(10)" />
        <signal name="XLXN_632" />
        <signal name="PWM_BASE(15:0)" />
        <signal name="CLK" />
        <signal name="XLXN_1728(7:0)" />
        <signal name="PWMBP" />
        <signal name="XLXN_2014" />
        <signal name="XLXN_2946(7:0)" />
        <signal name="XLXN_2948(7:0)" />
        <signal name="XLXN_3007" />
        <signal name="XLXN_2950" />
        <signal name="XLXN_2943" />
        <signal name="XLXN_58(7:0)" />
        <signal name="XLXN_77" />
        <signal name="SW(7:0)" />
        <signal name="XLXN_74(7:0)" />
        <signal name="XLXN_75" />
        <signal name="XLXN_76" />
        <signal name="XLXN_102" />
        <signal name="XLXN_1764" />
        <signal name="XLXN_1765" />
        <signal name="XLXN_1766" />
        <signal name="XLXN_1767" />
        <signal name="XLXN_1768" />
        <signal name="XLXN_1769" />
        <signal name="XLXN_1770" />
        <signal name="XLXN_1771" />
        <signal name="SWD(0)" />
        <signal name="SWD(1)" />
        <signal name="SWD(2)" />
        <signal name="SWD(3)" />
        <signal name="SWD(4)" />
        <signal name="SWD(5)" />
        <signal name="SWD(6)" />
        <signal name="SWD(7)" />
        <signal name="SAMPC(7:0)" />
        <signal name="XLXN_3047" />
        <signal name="SAMPC(4)" />
        <signal name="XLXN_3050" />
        <signal name="XLXN_2771" />
        <signal name="PSW2" />
        <signal name="SWD(7:0)" />
        <signal name="XLXN_2947" />
        <signal name="XLXN_2451" />
        <signal name="XLXN_3102" />
        <signal name="XLXN_1478" />
        <signal name="XLXN_3101" />
        <signal name="XLXN_3089" />
        <signal name="XLXN_130" />
        <signal name="XLXN_1615" />
        <signal name="XLXN_1611" />
        <signal name="XLXN_1528" />
        <signal name="MD_C" />
        <signal name="MD_A" />
        <signal name="XLXN_2760" />
        <signal name="XLXN_2761" />
        <signal name="XLXN_2663" />
        <signal name="XLXN_2757" />
        <signal name="XLXN_2924" />
        <signal name="XLXN_2756" />
        <signal name="XLXN_2925" />
        <signal name="XLXN_2859" />
        <signal name="XLXN_2770" />
        <signal name="XLXN_2706" />
        <signal name="XLXN_2707" />
        <signal name="XLXN_2708" />
        <signal name="XLXN_2732" />
        <signal name="PSW0" />
        <signal name="LED0" />
        <signal name="PSW1" />
        <signal name="LED1" />
        <signal name="XLXN_2745" />
        <signal name="XLXN_2768" />
        <signal name="XLXN_2769" />
        <signal name="MD_B" />
        <signal name="MD_D" />
        <signal name="XLXN_2709" />
        <signal name="XLXN_2764" />
        <signal name="XLXN_2922" />
        <signal name="XLXN_2765" />
        <signal name="XLXN_2923" />
        <signal name="XLXN_2704" />
        <signal name="XLXN_3292" />
        <signal name="XLXN_3704" />
        <port polarity="Input" name="CLK" />
        <port polarity="Input" name="SW(7:0)" />
        <port polarity="Input" name="PSW2" />
        <port polarity="Output" name="MD_C" />
        <port polarity="Output" name="MD_A" />
        <port polarity="Input" name="PSW0" />
        <port polarity="Output" name="LED0" />
        <port polarity="Input" name="PSW1" />
        <port polarity="Output" name="LED1" />
        <port polarity="Output" name="MD_B" />
        <port polarity="Output" name="MD_D" />
        <blockdef name="cb16re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="320" y1="-128" y2="-128" x1="384" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="320" y1="-192" y2="-192" x1="384" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="ibufg">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
        </blockdef>
        <blockdef name="vcc">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-64" x1="64" />
            <line x2="64" y1="0" y2="-32" x1="64" />
            <line x2="32" y1="-64" y2="-64" x1="96" />
        </blockdef>
        <blockdef name="inv">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="160" y1="-32" y2="-32" x1="224" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="64" y1="0" y2="-64" x1="64" />
            <circle r="16" cx="144" cy="-32" />
        </blockdef>
        <blockdef name="gnd">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-96" x1="64" />
            <line x2="52" y1="-48" y2="-48" x1="76" />
            <line x2="60" y1="-32" y2="-32" x1="68" />
            <line x2="40" y1="-64" y2="-64" x1="88" />
            <line x2="64" y1="-64" y2="-80" x1="64" />
            <line x2="64" y1="-128" y2="-96" x1="64" />
        </blockdef>
        <blockdef name="obuf">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
        </blockdef>
        <blockdef name="comp8">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="256" x="64" y="-384" height="320" />
            <line x2="320" y1="-224" y2="-224" x1="384" />
            <rect width="64" x="0" y="-332" height="24" />
            <line x2="64" y1="-320" y2="-320" x1="0" />
            <rect width="64" x="0" y="-140" height="24" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
        </blockdef>
        <blockdef name="fd">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="256" x="64" y="-320" height="256" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
        </blockdef>
        <blockdef name="buf">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <line x2="128" y1="0" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-64" x1="128" />
            <line x2="64" y1="-64" y2="0" x1="64" />
        </blockdef>
        <blockdef name="and8">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-512" x1="64" />
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="64" y1="-320" y2="-320" x1="0" />
            <line x2="64" y1="-384" y2="-384" x1="0" />
            <line x2="64" y1="-448" y2="-448" x1="0" />
            <line x2="64" y1="-512" y2="-512" x1="0" />
            <line x2="144" y1="-336" y2="-336" x1="64" />
            <line x2="64" y1="-240" y2="-240" x1="144" />
            <arc ex="144" ey="-336" sx="144" sy="-240" r="48" cx="144" cy="-288" />
            <line x2="192" y1="-288" y2="-288" x1="256" />
        </blockdef>
        <blockdef name="and2b1">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-48" y2="-144" x1="64" />
            <line x2="144" y1="-144" y2="-144" x1="64" />
            <line x2="64" y1="-48" y2="-48" x1="144" />
            <arc ex="144" ey="-144" sx="144" sy="-48" r="48" cx="144" cy="-96" />
            <line x2="192" y1="-96" y2="-96" x1="256" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="40" y1="-64" y2="-64" x1="0" />
            <circle r="12" cx="52" cy="-64" />
        </blockdef>
        <blockdef name="and2">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="192" y1="-96" y2="-96" x1="256" />
            <arc ex="144" ey="-144" sx="144" sy="-48" r="48" cx="144" cy="-96" />
            <line x2="64" y1="-48" y2="-48" x1="144" />
            <line x2="144" y1="-144" y2="-144" x1="64" />
            <line x2="64" y1="-48" y2="-144" x1="64" />
        </blockdef>
        <blockdef name="ftc">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="256" x="64" y="-320" height="256" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
        </blockdef>
        <blockdef name="cb8re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="320" y1="-192" y2="-192" x1="384" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="320" y1="-128" y2="-128" x1="384" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="xor2">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-64" y2="-64" x1="0" />
            <line x2="60" y1="-128" y2="-128" x1="0" />
            <line x2="208" y1="-96" y2="-96" x1="256" />
            <arc ex="44" ey="-144" sx="48" sy="-48" r="56" cx="16" cy="-96" />
            <arc ex="64" ey="-144" sx="64" sy="-48" r="56" cx="32" cy="-96" />
            <line x2="64" y1="-144" y2="-144" x1="128" />
            <line x2="64" y1="-48" y2="-48" x1="128" />
            <arc ex="128" ey="-144" sx="208" sy="-96" r="88" cx="132" cy="-56" />
            <arc ex="208" ey="-96" sx="128" sy="-48" r="88" cx="132" cy="-136" />
        </blockdef>
        <blockdef name="ibuf">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
        </blockdef>
        <blockdef name="fd8re">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="64" y1="-128" y2="-128" x1="0" />
            <line x2="64" y1="-192" y2="-192" x1="0" />
            <line x2="64" y1="-256" y2="-256" x1="0" />
            <line x2="320" y1="-256" y2="-256" x1="384" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
            <rect width="64" x="0" y="-268" height="24" />
            <rect width="64" x="320" y="-268" height="24" />
            <line x2="64" y1="-128" y2="-144" x1="80" />
            <line x2="80" y1="-112" y2="-128" x1="64" />
            <line x2="64" y1="-32" y2="-32" x1="192" />
            <line x2="192" y1="-64" y2="-32" x1="192" />
            <rect width="256" x="64" y="-320" height="256" />
        </blockdef>
        <blockdef name="ibuf8">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <rect width="96" x="128" y="-44" height="24" />
            <line x2="128" y1="-32" y2="-32" x1="224" />
            <rect width="64" x="0" y="-44" height="24" />
            <line x2="64" y1="0" y2="-64" x1="64" />
            <line x2="64" y1="-32" y2="0" x1="128" />
            <line x2="128" y1="-64" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-32" x1="0" />
        </blockdef>
        <blockdef name="m2_1">
            <timestamp>2000-1-1T10:10:10</timestamp>
            <line x2="96" y1="-64" y2="-192" x1="96" />
            <line x2="96" y1="-96" y2="-64" x1="256" />
            <line x2="256" y1="-160" y2="-96" x1="256" />
            <line x2="256" y1="-192" y2="-160" x1="96" />
            <line x2="96" y1="-32" y2="-32" x1="176" />
            <line x2="176" y1="-80" y2="-32" x1="176" />
            <line x2="96" y1="-32" y2="-32" x1="0" />
            <line x2="256" y1="-128" y2="-128" x1="320" />
            <line x2="96" y1="-96" y2="-96" x1="0" />
            <line x2="96" y1="-160" y2="-160" x1="0" />
        </blockdef>
        <blockdef name="constant">
            <timestamp>2006-1-1T10:10:10</timestamp>
            <rect width="112" x="0" y="0" height="64" />
            <line x2="112" y1="32" y2="32" x1="144" />
        </blockdef>
        <blockdef name="Trapezoid_PWM_GEN">
            <timestamp>2016-2-24T1:21:17</timestamp>
            <rect width="256" x="64" y="-320" height="320" />
            <rect width="64" x="0" y="-236" height="24" />
            <line x2="0" y1="-224" y2="-224" x1="64" />
            <line x2="0" y1="-32" y2="-32" x1="64" />
            <line x2="384" y1="-288" y2="-288" x1="320" />
            <line x2="72" y1="-40" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-24" x1="72" />
            <line x2="0" y1="-96" y2="-96" x1="64" />
            <line x2="0" y1="-160" y2="-160" x1="64" />
            <line x2="0" y1="-288" y2="-288" x1="64" />
            <line x2="384" y1="-96" y2="-96" x1="320" />
        </blockdef>
        <blockdef name="CHAT_FILTER">
            <timestamp>2008-11-11T0:42:30</timestamp>
            <rect width="256" x="64" y="-192" height="192" />
            <line x2="384" y1="-160" y2="-160" x1="320" />
            <line x2="0" y1="-160" y2="-160" x1="64" />
            <line x2="0" y1="-32" y2="-32" x1="64" />
            <line x2="0" y1="-96" y2="-96" x1="64" />
            <line x2="76" y1="-44" y2="-32" x1="64" />
            <line x2="64" y1="-32" y2="-20" x1="76" />
        </blockdef>
        <block symbolname="cb16re" name="XLXI_351">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="XLXN_632" name="CE" />
            <blockpin signalname="PWMBP" name="R" />
            <blockpin name="CEO" />
            <blockpin signalname="PWM_BASE(15:0)" name="Q(15:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="buf" name="XLXI_468">
            <blockpin signalname="PWM_BASE(10)" name="I" />
            <blockpin signalname="PWMBP" name="O" />
        </block>
        <block symbolname="vcc" name="XLXI_352">
            <blockpin signalname="XLXN_632" name="P" />
        </block>
        <block symbolname="ibufg" name="XLXI_5">
            <blockpin signalname="CLK" name="I" />
            <blockpin signalname="XLXN_3101" name="O" />
        </block>
        <block symbolname="fd" name="XLXI_1234">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="PWMBP" name="D" />
            <blockpin signalname="XLXN_2451" name="Q" />
        </block>
        <block symbolname="comp8" name="XLXI_1029">
            <blockpin signalname="XLXN_1728(7:0)" name="A(7:0)" />
            <blockpin signalname="SWD(7:0)" name="B(7:0)" />
            <blockpin signalname="XLXN_2014" name="EQ" />
        </block>
        <block symbolname="cb8re" name="XLXI_1038">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="PWMBP" name="CE" />
            <blockpin signalname="XLXN_2014" name="R" />
            <blockpin name="CEO" />
            <blockpin signalname="XLXN_1728(7:0)" name="Q(7:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="m2_1" name="XLXI_1605">
            <blockpin signalname="XLXN_2014" name="D0" />
            <blockpin signalname="XLXN_3007" name="D1" />
            <blockpin signalname="XLXN_2950" name="S0" />
            <blockpin signalname="XLXN_3102" name="O" />
        </block>
        <block symbolname="fd8re" name="XLXI_9">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="XLXN_102" name="CE" />
            <blockpin signalname="XLXN_58(7:0)" name="D(7:0)" />
            <blockpin signalname="XLXN_77" name="R" />
            <blockpin signalname="SWD(7:0)" name="Q(7:0)" />
        </block>
        <block symbolname="gnd" name="XLXI_56">
            <blockpin signalname="XLXN_77" name="G" />
        </block>
        <block symbolname="ibuf8" name="XLXI_11">
            <blockpin signalname="SW(7:0)" name="I(7:0)" />
            <blockpin signalname="XLXN_74(7:0)" name="O(7:0)" />
        </block>
        <block symbolname="fd8re" name="XLXI_31">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="XLXN_75" name="CE" />
            <blockpin signalname="XLXN_74(7:0)" name="D(7:0)" />
            <blockpin signalname="XLXN_76" name="R" />
            <blockpin signalname="XLXN_58(7:0)" name="Q(7:0)" />
        </block>
        <block symbolname="vcc" name="XLXI_54">
            <blockpin signalname="XLXN_75" name="P" />
        </block>
        <block symbolname="gnd" name="XLXI_55">
            <blockpin signalname="XLXN_76" name="G" />
        </block>
        <block symbolname="vcc" name="XLXI_74">
            <blockpin signalname="XLXN_102" name="P" />
        </block>
        <block symbolname="inv" name="XLXI_1066">
            <blockpin signalname="SWD(0)" name="I" />
            <blockpin signalname="XLXN_1771" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1067">
            <blockpin signalname="SWD(1)" name="I" />
            <blockpin signalname="XLXN_1770" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1068">
            <blockpin signalname="SWD(2)" name="I" />
            <blockpin signalname="XLXN_1769" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1069">
            <blockpin signalname="SWD(3)" name="I" />
            <blockpin signalname="XLXN_1768" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1070">
            <blockpin signalname="SWD(6)" name="I" />
            <blockpin signalname="XLXN_1765" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1071">
            <blockpin signalname="SWD(7)" name="I" />
            <blockpin signalname="XLXN_1764" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1072">
            <blockpin signalname="SWD(4)" name="I" />
            <blockpin signalname="XLXN_1767" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1073">
            <blockpin signalname="SWD(5)" name="I" />
            <blockpin signalname="XLXN_1766" name="O" />
        </block>
        <block symbolname="and8" name="XLXI_1074">
            <blockpin signalname="XLXN_1764" name="I0" />
            <blockpin signalname="XLXN_1765" name="I1" />
            <blockpin signalname="XLXN_1766" name="I2" />
            <blockpin signalname="XLXN_1767" name="I3" />
            <blockpin signalname="XLXN_1768" name="I4" />
            <blockpin signalname="XLXN_1769" name="I5" />
            <blockpin signalname="XLXN_1770" name="I6" />
            <blockpin signalname="XLXN_1771" name="I7" />
            <blockpin signalname="XLXN_2950" name="O" />
        </block>
        <block symbolname="CHAT_FILTER" name="XLXI_1709">
            <blockpin signalname="XLXN_3007" name="DOUT_ONE" />
            <blockpin signalname="XLXN_2771" name="DIN" />
            <blockpin signalname="XLXN_3101" name="CLK" />
            <blockpin signalname="SAMPC(4)" name="CE" />
        </block>
        <block symbolname="cb8re" name="XLXI_1730">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="XLXN_3047" name="CE" />
            <blockpin signalname="SAMPC(4)" name="R" />
            <blockpin name="CEO" />
            <blockpin signalname="SAMPC(7:0)" name="Q(7:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="cb16re" name="XLXI_1731">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="XLXN_3050" name="CE" />
            <blockpin signalname="SAMPC(4)" name="R" />
            <blockpin signalname="XLXN_3047" name="CEO" />
            <blockpin name="Q(15:0)" />
            <blockpin name="TC" />
        </block>
        <block symbolname="vcc" name="XLXI_1733">
            <blockpin signalname="XLXN_3050" name="P" />
        </block>
        <block symbolname="ibuf" name="XLXI_1603">
            <blockpin signalname="PSW2" name="I" />
            <blockpin signalname="XLXN_2771" name="O" />
        </block>
        <block symbolname="constant" name="XLXI_1676">
            <attr value="40" name="CValue">
                <trait delete="all:1 sym:0" />
                <trait editname="all:1 sch:0" />
                <trait valuetype="BitVector 32 Hexadecimal" />
            </attr>
            <blockpin signalname="XLXN_2948(7:0)" name="O" />
        </block>
        <block symbolname="constant" name="XLXI_1674">
            <attr value="00" name="CValue">
                <trait delete="all:1 sym:0" />
                <trait editname="all:1 sch:0" />
                <trait valuetype="BitVector 32 Hexadecimal" />
            </attr>
            <blockpin signalname="XLXN_2946(7:0)" name="O" />
        </block>
        <block symbolname="gnd" name="XLXI_1673">
            <blockpin signalname="XLXN_2947" name="G" />
        </block>
        <block symbolname="Trapezoid_PWM_GEN" name="XLXI_1672">
            <blockpin signalname="XLXN_2946(7:0)" name="D(7:0)" />
            <blockpin signalname="XLXN_3101" name="CLK" />
            <blockpin signalname="XLXN_130" name="PWMOUT" />
            <blockpin signalname="XLXN_3102" name="CE" />
            <blockpin signalname="XLXN_2947" name="L" />
            <blockpin signalname="XLXN_2451" name="PWMBP" />
            <blockpin signalname="XLXN_2859" name="ZERO" />
        </block>
        <block symbolname="Trapezoid_PWM_GEN" name="XLXI_1675">
            <blockpin signalname="XLXN_2948(7:0)" name="D(7:0)" />
            <blockpin signalname="XLXN_3101" name="CLK" />
            <blockpin signalname="XLXN_2704" name="PWMOUT" />
            <blockpin signalname="XLXN_3102" name="CE" />
            <blockpin signalname="XLXN_3089" name="L" />
            <blockpin signalname="XLXN_2451" name="PWMBP" />
            <blockpin signalname="XLXN_3292" name="ZERO" />
        </block>
        <block symbolname="fd" name="XLXI_912">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="XLXN_3704" name="D" />
            <blockpin signalname="XLXN_1478" name="Q" />
        </block>
        <block symbolname="vcc" name="XLXI_921">
            <blockpin signalname="XLXN_3704" name="P" />
        </block>
        <block symbolname="and2b1" name="XLXI_86">
            <blockpin signalname="XLXN_2663" name="I0" />
            <blockpin signalname="XLXN_130" name="I1" />
            <blockpin signalname="XLXN_2757" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_1002">
            <blockpin signalname="XLXN_1611" name="I0" />
            <blockpin signalname="XLXN_2859" name="I1" />
            <blockpin signalname="XLXN_1615" name="O" />
        </block>
        <block symbolname="fd" name="XLXI_1001">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="XLXN_2859" name="D" />
            <blockpin signalname="XLXN_1611" name="Q" />
        </block>
        <block symbolname="gnd" name="XLXI_945">
            <blockpin signalname="XLXN_1528" name="G" />
        </block>
        <block symbolname="ftc" name="XLXI_944">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="XLXN_1528" name="CLR" />
            <blockpin signalname="XLXN_1615" name="T" />
            <blockpin signalname="XLXN_2663" name="Q" />
        </block>
        <block symbolname="obuf" name="XLXI_78">
            <blockpin signalname="XLXN_2761" name="I" />
            <blockpin signalname="MD_C" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_125">
            <blockpin signalname="XLXN_2770" name="I0" />
            <blockpin signalname="XLXN_2924" name="I1" />
            <blockpin signalname="XLXN_2761" name="O" />
        </block>
        <block symbolname="and2" name="XLXI_85">
            <blockpin signalname="XLXN_2663" name="I0" />
            <blockpin signalname="XLXN_130" name="I1" />
            <blockpin signalname="XLXN_2756" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_124">
            <blockpin signalname="XLXN_2770" name="I0" />
            <blockpin signalname="XLXN_2925" name="I1" />
            <blockpin signalname="XLXN_2760" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_76">
            <blockpin signalname="XLXN_2760" name="I" />
            <blockpin signalname="MD_A" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1667">
            <blockpin signalname="XLXN_2756" name="I" />
            <blockpin signalname="XLXN_2925" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1668">
            <blockpin signalname="XLXN_2757" name="I" />
            <blockpin signalname="XLXN_2924" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_1559">
            <blockpin signalname="XLXN_2709" name="I0" />
            <blockpin signalname="XLXN_2704" name="I1" />
            <blockpin signalname="XLXN_2765" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_1561">
            <blockpin signalname="XLXN_2707" name="I0" />
            <blockpin signalname="XLXN_3292" name="I1" />
            <blockpin signalname="XLXN_2706" name="O" />
        </block>
        <block symbolname="fd" name="XLXI_1562">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="XLXN_3292" name="D" />
            <blockpin signalname="XLXN_2707" name="Q" />
        </block>
        <block symbolname="gnd" name="XLXI_1563">
            <blockpin signalname="XLXN_2708" name="G" />
        </block>
        <block symbolname="ftc" name="XLXI_1564">
            <blockpin signalname="XLXN_3101" name="C" />
            <blockpin signalname="XLXN_2708" name="CLR" />
            <blockpin signalname="XLXN_2706" name="T" />
            <blockpin signalname="XLXN_2732" name="Q" />
        </block>
        <block symbolname="ibuf" name="XLXI_233">
            <blockpin signalname="PSW0" name="I" />
            <blockpin signalname="XLXN_2745" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_118">
            <blockpin signalname="XLXN_2745" name="I" />
            <blockpin signalname="LED0" name="O" />
        </block>
        <block symbolname="ibuf" name="XLXI_1065">
            <blockpin signalname="PSW1" name="I" />
            <blockpin signalname="XLXN_2770" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_1064">
            <blockpin signalname="XLXN_2770" name="I" />
            <blockpin signalname="LED1" name="O" />
        </block>
        <block symbolname="xor2" name="XLXI_1026">
            <blockpin signalname="XLXN_2745" name="I0" />
            <blockpin signalname="XLXN_2732" name="I1" />
            <blockpin signalname="XLXN_2709" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_1596">
            <blockpin signalname="XLXN_2770" name="I0" />
            <blockpin signalname="XLXN_2923" name="I1" />
            <blockpin signalname="XLXN_2769" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_845">
            <blockpin signalname="XLXN_2769" name="I" />
            <blockpin signalname="MD_D" name="O" />
        </block>
        <block symbolname="and2" name="XLXI_1560">
            <blockpin signalname="XLXN_2709" name="I0" />
            <blockpin signalname="XLXN_2704" name="I1" />
            <blockpin signalname="XLXN_2764" name="O" />
        </block>
        <block symbolname="and2b1" name="XLXI_1595">
            <blockpin signalname="XLXN_2770" name="I0" />
            <blockpin signalname="XLXN_2922" name="I1" />
            <blockpin signalname="XLXN_2768" name="O" />
        </block>
        <block symbolname="obuf" name="XLXI_833">
            <blockpin signalname="XLXN_2768" name="I" />
            <blockpin signalname="MD_B" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1669">
            <blockpin signalname="XLXN_2764" name="I" />
            <blockpin signalname="XLXN_2922" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1670">
            <blockpin signalname="XLXN_2765" name="I" />
            <blockpin signalname="XLXN_2923" name="O" />
        </block>
        <block symbolname="inv" name="XLXI_1734">
            <blockpin signalname="XLXN_1478" name="I" />
            <blockpin signalname="XLXN_3089" name="O" />
        </block>
    </netlist>
    <sheet sheetnum="1" width="7040" height="5440">
        <attr value="Inch" name="LengthUnitName" />
        <attr value="10" name="GridsPerUnit" />
        <instance x="1248" y="1680" name="XLXI_351" orien="R0" />
        <rect style="linewidth:W;linecolor:rgb(0,0,255);linestyle:Dash" width="1352" x="1056" y="1256" height="568" />
        <instance x="2016" y="1552" name="XLXI_468" orien="R0" />
        <bustap x2="1856" y1="1520" y2="1520" x1="1760" />
        <instance x="1136" y="1440" name="XLXI_352" orien="R0" />
        <branch name="PWM_BASE(10)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="1904" y="1520" type="branch" />
            <wire x2="1904" y1="1520" y2="1520" x1="1856" />
            <wire x2="2016" y1="1520" y2="1520" x1="1904" />
        </branch>
        <branch name="XLXN_632">
            <wire x2="1200" y1="1440" y2="1488" x1="1200" />
            <wire x2="1248" y1="1488" y2="1488" x1="1200" />
        </branch>
        <branch name="PWM_BASE(15:0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="1760" y="1424" type="branch" />
            <wire x2="1760" y1="1424" y2="1424" x1="1632" />
            <wire x2="1760" y1="1424" y2="1520" x1="1760" />
        </branch>
        <branch name="CLK">
            <wire x2="848" y1="1552" y2="1552" x1="816" />
        </branch>
        <text style="fontsize:48;fontname:Arial" x="1068" y="1224">PWM Base Cycle Generate (48.8kHz@50MHz CLK)</text>
        <instance x="848" y="1584" name="XLXI_5" orien="R0" />
        <text style="fontsize:48;fontname:Arial" x="736" y="1496">50MHz</text>
        <branch name="XLXN_1728(7:0)">
            <wire x2="2080" y1="2032" y2="2032" x1="1904" />
        </branch>
        <text style="fontsize:48;fontname:Arial" x="464" y="856">Microstep Ctrl</text>
        <text style="fontsize:48;fontname:Arial" x="468" y="928">with reverse switch</text>
        <branch name="PWMBP">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2320" y="1520" type="branch" />
            <wire x2="1248" y1="1648" y2="1648" x1="1168" />
            <wire x2="1168" y1="1648" y2="1744" x1="1168" />
            <wire x2="1488" y1="1744" y2="1744" x1="1168" />
            <wire x2="2352" y1="1744" y2="1744" x1="1488" />
            <wire x2="1488" y1="1744" y2="2096" x1="1488" />
            <wire x2="1520" y1="2096" y2="2096" x1="1488" />
            <wire x2="2320" y1="1520" y2="1520" x1="2240" />
            <wire x2="2352" y1="1520" y2="1520" x1="2320" />
            <wire x2="2352" y1="1520" y2="1744" x1="2352" />
            <wire x2="2544" y1="1520" y2="1520" x1="2352" />
        </branch>
        <instance x="2544" y="1776" name="XLXI_1234" orien="R0" />
        <instance x="2080" y="2352" name="XLXI_1029" orien="R0" />
        <instance x="1520" y="2288" name="XLXI_1038" orien="R0" />
        <branch name="XLXN_2014">
            <wire x2="1520" y1="2256" y2="2352" x1="1520" />
            <wire x2="2512" y1="2352" y2="2352" x1="1520" />
            <wire x2="2512" y1="2128" y2="2128" x1="2464" />
            <wire x2="2512" y1="2128" y2="2352" x1="2512" />
            <wire x2="2592" y1="2128" y2="2128" x1="2512" />
        </branch>
        <instance x="2592" y="2288" name="XLXI_1605" orien="R0" />
        <branch name="XLXN_2946(7:0)">
            <wire x2="3744" y1="1584" y2="1584" x1="3568" />
        </branch>
        <branch name="XLXN_2948(7:0)">
            <wire x2="3744" y1="2160" y2="2160" x1="3568" />
        </branch>
        <branch name="XLXN_3007">
            <wire x2="2560" y1="2768" y2="2768" x1="2528" />
            <wire x2="2560" y1="2192" y2="2768" x1="2560" />
            <wire x2="2592" y1="2192" y2="2192" x1="2560" />
        </branch>
        <branch name="XLXN_2950">
            <wire x2="2592" y1="2256" y2="2336" x1="2592" />
            <wire x2="2864" y1="2336" y2="2336" x1="2592" />
            <wire x2="2864" y1="2336" y2="3712" x1="2864" />
            <wire x2="2864" y1="3712" y2="3712" x1="2848" />
        </branch>
        <branch name="XLXN_58(7:0)">
            <wire x2="1696" y1="3408" y2="3408" x1="1504" />
        </branch>
        <branch name="XLXN_77">
            <wire x2="1696" y1="3632" y2="3632" x1="1664" />
            <wire x2="1664" y1="3632" y2="3664" x1="1664" />
        </branch>
        <branch name="SW(7:0)">
            <wire x2="752" y1="3408" y2="3408" x1="656" />
        </branch>
        <branch name="XLXN_74(7:0)">
            <wire x2="1120" y1="3408" y2="3408" x1="976" />
        </branch>
        <branch name="XLXN_75">
            <wire x2="1056" y1="3344" y2="3472" x1="1056" />
            <wire x2="1120" y1="3472" y2="3472" x1="1056" />
        </branch>
        <branch name="XLXN_76">
            <wire x2="1072" y1="3632" y2="3664" x1="1072" />
            <wire x2="1120" y1="3632" y2="3632" x1="1072" />
        </branch>
        <branch name="XLXN_102">
            <wire x2="1648" y1="3344" y2="3472" x1="1648" />
            <wire x2="1696" y1="3472" y2="3472" x1="1648" />
        </branch>
        <instance x="1696" y="3664" name="XLXI_9" orien="R0" />
        <instance x="1600" y="3792" name="XLXI_56" orien="R0" />
        <instance x="752" y="3440" name="XLXI_11" orien="R0" />
        <instance x="1120" y="3664" name="XLXI_31" orien="R0" />
        <instance x="992" y="3344" name="XLXI_54" orien="R0" />
        <instance x="1008" y="3792" name="XLXI_55" orien="R0" />
        <instance x="1584" y="3344" name="XLXI_74" orien="R0" />
        <text style="fontsize:48;fontname:Arial" x="516" y="3276">Switch Input</text>
        <branch name="XLXN_1764">
            <wire x2="2592" y1="3936" y2="3936" x1="2560" />
        </branch>
        <branch name="XLXN_1765">
            <wire x2="2592" y1="3872" y2="3872" x1="2560" />
        </branch>
        <branch name="XLXN_1766">
            <wire x2="2592" y1="3808" y2="3808" x1="2560" />
        </branch>
        <branch name="XLXN_1767">
            <wire x2="2592" y1="3744" y2="3744" x1="2560" />
        </branch>
        <branch name="XLXN_1768">
            <wire x2="2592" y1="3680" y2="3680" x1="2560" />
        </branch>
        <branch name="XLXN_1769">
            <wire x2="2592" y1="3616" y2="3616" x1="2560" />
        </branch>
        <branch name="XLXN_1770">
            <wire x2="2592" y1="3552" y2="3552" x1="2560" />
        </branch>
        <branch name="XLXN_1771">
            <wire x2="2592" y1="3488" y2="3488" x1="2560" />
        </branch>
        <instance x="2336" y="3520" name="XLXI_1066" orien="R0" />
        <instance x="2336" y="3584" name="XLXI_1067" orien="R0" />
        <instance x="2336" y="3648" name="XLXI_1068" orien="R0" />
        <instance x="2336" y="3712" name="XLXI_1069" orien="R0" />
        <instance x="2336" y="3904" name="XLXI_1070" orien="R0" />
        <instance x="2336" y="3968" name="XLXI_1071" orien="R0" />
        <instance x="2336" y="3776" name="XLXI_1072" orien="R0" />
        <instance x="2336" y="3840" name="XLXI_1073" orien="R0" />
        <instance x="2592" y="4000" name="XLXI_1074" orien="R0" />
        <bustap x2="2240" y1="3936" y2="3936" x1="2144" />
        <bustap x2="2240" y1="3872" y2="3872" x1="2144" />
        <bustap x2="2240" y1="3808" y2="3808" x1="2144" />
        <bustap x2="2240" y1="3744" y2="3744" x1="2144" />
        <bustap x2="2240" y1="3680" y2="3680" x1="2144" />
        <bustap x2="2240" y1="3616" y2="3616" x1="2144" />
        <bustap x2="2240" y1="3552" y2="3552" x1="2144" />
        <bustap x2="2240" y1="3488" y2="3488" x1="2144" />
        <branch name="SWD(0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2272" y="3488" type="branch" />
            <wire x2="2272" y1="3488" y2="3488" x1="2240" />
            <wire x2="2336" y1="3488" y2="3488" x1="2272" />
        </branch>
        <branch name="SWD(1)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2272" y="3552" type="branch" />
            <wire x2="2272" y1="3552" y2="3552" x1="2240" />
            <wire x2="2336" y1="3552" y2="3552" x1="2272" />
        </branch>
        <branch name="SWD(2)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2272" y="3616" type="branch" />
            <wire x2="2272" y1="3616" y2="3616" x1="2240" />
            <wire x2="2336" y1="3616" y2="3616" x1="2272" />
        </branch>
        <branch name="SWD(3)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2272" y="3680" type="branch" />
            <wire x2="2272" y1="3680" y2="3680" x1="2240" />
            <wire x2="2336" y1="3680" y2="3680" x1="2272" />
        </branch>
        <branch name="SWD(4)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2272" y="3744" type="branch" />
            <wire x2="2272" y1="3744" y2="3744" x1="2240" />
            <wire x2="2336" y1="3744" y2="3744" x1="2272" />
        </branch>
        <branch name="SWD(5)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2272" y="3808" type="branch" />
            <wire x2="2272" y1="3808" y2="3808" x1="2240" />
            <wire x2="2336" y1="3808" y2="3808" x1="2272" />
        </branch>
        <branch name="SWD(6)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2272" y="3872" type="branch" />
            <wire x2="2272" y1="3872" y2="3872" x1="2240" />
            <wire x2="2336" y1="3872" y2="3872" x1="2272" />
        </branch>
        <branch name="SWD(7)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2272" y="3936" type="branch" />
            <wire x2="2272" y1="3936" y2="3936" x1="2240" />
            <wire x2="2336" y1="3936" y2="3936" x1="2272" />
        </branch>
        <instance x="2144" y="2928" name="XLXI_1709" orien="R0">
        </instance>
        <branch name="SAMPC(7:0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="1856" y="2752" type="branch" />
            <wire x2="1856" y1="2752" y2="2752" x1="1792" />
            <wire x2="1856" y1="2752" y2="2832" x1="1856" />
        </branch>
        <bustap x2="1952" y1="2832" y2="2832" x1="1856" />
        <instance x="1408" y="3008" name="XLXI_1730" orien="R0" />
        <instance x="896" y="3008" name="XLXI_1731" orien="R0" />
        <branch name="XLXN_3047">
            <wire x2="1408" y1="2816" y2="2816" x1="1280" />
        </branch>
        <branch name="SAMPC(4)">
            <attrtext style="alignment:SOFT-LEFT;fontsize:28;fontname:Arial" attrname="Name" x="2007" y="2832" type="branch" />
            <wire x2="896" y1="2976" y2="3088" x1="896" />
            <wire x2="1408" y1="3088" y2="3088" x1="896" />
            <wire x2="2016" y1="3088" y2="3088" x1="1408" />
            <wire x2="1408" y1="2976" y2="3088" x1="1408" />
            <wire x2="2016" y1="2832" y2="2832" x1="1952" />
            <wire x2="2144" y1="2832" y2="2832" x1="2016" />
            <wire x2="2016" y1="2832" y2="3088" x1="2016" />
        </branch>
        <instance x="784" y="2784" name="XLXI_1733" orien="R0" />
        <branch name="XLXN_3050">
            <wire x2="848" y1="2784" y2="2816" x1="848" />
            <wire x2="896" y1="2816" y2="2816" x1="848" />
        </branch>
        <branch name="XLXN_2771">
            <wire x2="2064" y1="2544" y2="2544" x1="928" />
            <wire x2="2064" y1="2544" y2="2768" x1="2064" />
            <wire x2="2144" y1="2768" y2="2768" x1="2064" />
        </branch>
        <branch name="PSW2">
            <wire x2="704" y1="2544" y2="2544" x1="672" />
        </branch>
        <instance x="704" y="2576" name="XLXI_1603" orien="R0" />
        <branch name="SWD(7:0)">
            <attrtext style="alignment:SOFT-BCENTER;fontsize:28;fontname:Arial" attrname="Name" x="2208" y="3312" type="branch" />
            <wire x2="2016" y1="2224" y2="2400" x1="2016" />
            <wire x2="2672" y1="2400" y2="2400" x1="2016" />
            <wire x2="2672" y1="2400" y2="3312" x1="2672" />
            <wire x2="2080" y1="2224" y2="2224" x1="2016" />
            <wire x2="2144" y1="3408" y2="3408" x1="2080" />
            <wire x2="2144" y1="3408" y2="3488" x1="2144" />
            <wire x2="2144" y1="3488" y2="3552" x1="2144" />
            <wire x2="2144" y1="3552" y2="3616" x1="2144" />
            <wire x2="2144" y1="3616" y2="3680" x1="2144" />
            <wire x2="2144" y1="3680" y2="3744" x1="2144" />
            <wire x2="2144" y1="3744" y2="3808" x1="2144" />
            <wire x2="2144" y1="3808" y2="3872" x1="2144" />
            <wire x2="2144" y1="3872" y2="3936" x1="2144" />
            <wire x2="2144" y1="3312" y2="3408" x1="2144" />
            <wire x2="2208" y1="3312" y2="3312" x1="2144" />
            <wire x2="2672" y1="3312" y2="3312" x1="2208" />
        </branch>
        <instance x="3424" y="2128" name="XLXI_1676" orien="R0">
        </instance>
        <instance x="3424" y="1552" name="XLXI_1674" orien="R0">
        </instance>
        <instance x="3744" y="1808" name="XLXI_1672" orien="R0">
        </instance>
        <branch name="XLXN_2947">
            <wire x2="3616" y1="1648" y2="1744" x1="3616" />
            <wire x2="3744" y1="1648" y2="1648" x1="3616" />
        </branch>
        <instance x="3744" y="2384" name="XLXI_1675" orien="R0">
        </instance>
        <branch name="XLXN_2451">
            <wire x2="3264" y1="1520" y2="1520" x1="2928" />
            <wire x2="3744" y1="1520" y2="1520" x1="3264" />
            <wire x2="3264" y1="1520" y2="2096" x1="3264" />
            <wire x2="3744" y1="2096" y2="2096" x1="3264" />
        </branch>
        <branch name="XLXN_3102">
            <wire x2="2992" y1="2160" y2="2160" x1="2912" />
            <wire x2="2992" y1="2160" y2="2288" x1="2992" />
            <wire x2="3744" y1="2288" y2="2288" x1="2992" />
            <wire x2="2992" y1="1712" y2="2160" x1="2992" />
            <wire x2="3744" y1="1712" y2="1712" x1="2992" />
        </branch>
        <branch name="XLXN_1478">
            <wire x2="3616" y1="2784" y2="2784" x1="3520" />
        </branch>
        <branch name="XLXN_3101">
            <wire x2="896" y1="2880" y2="2880" x1="832" />
            <wire x2="832" y1="2880" y2="3040" x1="832" />
            <wire x2="1344" y1="3040" y2="3040" x1="832" />
            <wire x2="2096" y1="3040" y2="3040" x1="1344" />
            <wire x2="2768" y1="3040" y2="3040" x1="2096" />
            <wire x2="3056" y1="3040" y2="3040" x1="2768" />
            <wire x2="3056" y1="3040" y2="3904" x1="3056" />
            <wire x2="3056" y1="3904" y2="4048" x1="3056" />
            <wire x2="4352" y1="3904" y2="3904" x1="3056" />
            <wire x2="5168" y1="3904" y2="3904" x1="4352" />
            <wire x2="1120" y1="3536" y2="3536" x1="960" />
            <wire x2="960" y1="3536" y2="4048" x1="960" />
            <wire x2="1552" y1="4048" y2="4048" x1="960" />
            <wire x2="3056" y1="4048" y2="4048" x1="1552" />
            <wire x2="1120" y1="1552" y2="1552" x1="1072" />
            <wire x2="1248" y1="1552" y2="1552" x1="1120" />
            <wire x2="1120" y1="1552" y2="1856" x1="1120" />
            <wire x2="1440" y1="1856" y2="1856" x1="1120" />
            <wire x2="2480" y1="1856" y2="1856" x1="1440" />
            <wire x2="1440" y1="1856" y2="2160" x1="1440" />
            <wire x2="1520" y1="2160" y2="2160" x1="1440" />
            <wire x2="1440" y1="2160" y2="2448" x1="1440" />
            <wire x2="2768" y1="2448" y2="2448" x1="1440" />
            <wire x2="3696" y1="2448" y2="2448" x1="2768" />
            <wire x2="2768" y1="2448" y2="3040" x1="2768" />
            <wire x2="1408" y1="2880" y2="2880" x1="1344" />
            <wire x2="1344" y1="2880" y2="3040" x1="1344" />
            <wire x2="1696" y1="3536" y2="3536" x1="1552" />
            <wire x2="1552" y1="3536" y2="4048" x1="1552" />
            <wire x2="2144" y1="2896" y2="2896" x1="2096" />
            <wire x2="2096" y1="2896" y2="3040" x1="2096" />
            <wire x2="2544" y1="1648" y2="1648" x1="2480" />
            <wire x2="2480" y1="1648" y2="1856" x1="2480" />
            <wire x2="3136" y1="2912" y2="2912" x1="3056" />
            <wire x2="3056" y1="2912" y2="3040" x1="3056" />
            <wire x2="3744" y1="1776" y2="1776" x1="3696" />
            <wire x2="3696" y1="1776" y2="2352" x1="3696" />
            <wire x2="3744" y1="2352" y2="2352" x1="3696" />
            <wire x2="3696" y1="2352" y2="2448" x1="3696" />
            <wire x2="4352" y1="2432" y2="2560" x1="4352" />
            <wire x2="5152" y1="2560" y2="2560" x1="4352" />
            <wire x2="4352" y1="2560" y2="3776" x1="4352" />
            <wire x2="4480" y1="3776" y2="3776" x1="4352" />
            <wire x2="4352" y1="3776" y2="3904" x1="4352" />
            <wire x2="4464" y1="2432" y2="2432" x1="4352" />
            <wire x2="5248" y1="2400" y2="2400" x1="5152" />
            <wire x2="5152" y1="2400" y2="2560" x1="5152" />
            <wire x2="5264" y1="3744" y2="3744" x1="5168" />
            <wire x2="5168" y1="3744" y2="3904" x1="5168" />
        </branch>
        <instance x="3136" y="3040" name="XLXI_912" orien="R0" />
        <branch name="XLXN_130">
            <wire x2="4528" y1="1520" y2="1520" x1="4128" />
            <wire x2="4528" y1="1520" y2="1744" x1="4528" />
            <wire x2="4624" y1="1744" y2="1744" x1="4528" />
            <wire x2="4624" y1="1520" y2="1520" x1="4528" />
        </branch>
        <branch name="XLXN_1615">
            <wire x2="5248" y1="2272" y2="2272" x1="5200" />
        </branch>
        <branch name="XLXN_1611">
            <wire x2="4944" y1="2304" y2="2304" x1="4848" />
        </branch>
        <branch name="XLXN_1528">
            <wire x2="5216" y1="2496" y2="2528" x1="5216" />
            <wire x2="5248" y1="2496" y2="2496" x1="5216" />
        </branch>
        <branch name="MD_C">
            <wire x2="5984" y1="1808" y2="1808" x1="5904" />
        </branch>
        <branch name="MD_A">
            <wire x2="5984" y1="1584" y2="1584" x1="5904" />
        </branch>
        <branch name="XLXN_2760">
            <wire x2="5680" y1="1584" y2="1584" x1="5536" />
        </branch>
        <branch name="XLXN_2761">
            <wire x2="5680" y1="1808" y2="1808" x1="5536" />
        </branch>
        <branch name="XLXN_2663">
            <wire x2="4624" y1="1584" y2="1584" x1="4576" />
            <wire x2="4576" y1="1584" y2="1808" x1="4576" />
            <wire x2="4624" y1="1808" y2="1808" x1="4576" />
            <wire x2="4576" y1="1808" y2="2016" x1="4576" />
            <wire x2="5728" y1="2016" y2="2016" x1="4576" />
            <wire x2="5728" y1="2016" y2="2272" x1="5728" />
            <wire x2="5728" y1="2272" y2="2272" x1="5632" />
        </branch>
        <branch name="XLXN_2757">
            <wire x2="4928" y1="1776" y2="1776" x1="4880" />
        </branch>
        <branch name="XLXN_2924">
            <wire x2="5280" y1="1776" y2="1776" x1="5152" />
        </branch>
        <branch name="XLXN_2756">
            <wire x2="4928" y1="1552" y2="1552" x1="4880" />
        </branch>
        <branch name="XLXN_2925">
            <wire x2="5280" y1="1552" y2="1552" x1="5152" />
        </branch>
        <branch name="XLXN_2859">
            <wire x2="4400" y1="1712" y2="1712" x1="4128" />
            <wire x2="4400" y1="1712" y2="2128" x1="4400" />
            <wire x2="4928" y1="2128" y2="2128" x1="4400" />
            <wire x2="4928" y1="2128" y2="2240" x1="4928" />
            <wire x2="4944" y1="2240" y2="2240" x1="4928" />
            <wire x2="4400" y1="2128" y2="2304" x1="4400" />
            <wire x2="4464" y1="2304" y2="2304" x1="4400" />
        </branch>
        <branch name="XLXN_2770">
            <wire x2="5280" y1="1616" y2="1616" x1="5248" />
            <wire x2="5248" y1="1616" y2="1840" x1="5248" />
            <wire x2="5280" y1="1840" y2="1840" x1="5248" />
            <wire x2="5248" y1="1840" y2="1920" x1="5248" />
            <wire x2="6224" y1="1920" y2="1920" x1="5248" />
            <wire x2="6224" y1="1920" y2="3264" x1="6224" />
            <wire x2="6224" y1="3264" y2="3776" x1="6224" />
            <wire x2="5296" y1="2960" y2="2960" x1="5264" />
            <wire x2="5264" y1="2960" y2="3184" x1="5264" />
            <wire x2="5296" y1="3184" y2="3184" x1="5264" />
            <wire x2="5264" y1="3184" y2="3264" x1="5264" />
            <wire x2="6224" y1="3264" y2="3264" x1="5264" />
            <wire x2="5744" y1="4208" y2="4208" x1="5568" />
            <wire x2="5904" y1="4208" y2="4208" x1="5744" />
            <wire x2="5744" y1="3776" y2="4208" x1="5744" />
            <wire x2="6224" y1="3776" y2="3776" x1="5744" />
        </branch>
        <text style="fontsize:48;fontname:Arial" x="4456" y="1412">(Decimal Decoder)</text>
        <text style="fontsize:48;fontname:Arial" x="4456" y="1364">Exchange MD1/MD2</text>
        <rect style="linecolor:rgb(0,0,255);linestyle:Dash" width="404" x="4464" y="1448" height="476" />
        <instance x="4624" y="1872" name="XLXI_86" orien="R0" />
        <instance x="4944" y="2368" name="XLXI_1002" orien="R0" />
        <instance x="4464" y="2560" name="XLXI_1001" orien="R0" />
        <instance x="5152" y="2656" name="XLXI_945" orien="R0" />
        <instance x="5248" y="2528" name="XLXI_944" orien="R0" />
        <instance x="5680" y="1840" name="XLXI_78" orien="R0" />
        <text style="fontsize:48;fontname:Arial" x="5700" y="1512">To a motor driver</text>
        <instance x="5280" y="1904" name="XLXI_125" orien="R0" />
        <rect style="linecolor:rgb(0,0,255);linestyle:Dash" width="348" x="5192" y="1480" height="468" />
        <text style="fontsize:48;fontname:Arial" x="5228" y="1448">Output Inhibit</text>
        <instance x="4624" y="1648" name="XLXI_85" orien="R0" />
        <instance x="5280" y="1680" name="XLXI_124" orien="R0" />
        <instance x="5680" y="1616" name="XLXI_76" orien="R0" />
        <instance x="4928" y="1584" name="XLXI_1667" orien="R0" />
        <instance x="4928" y="1808" name="XLXI_1668" orien="R0" />
        <branch name="XLXN_2706">
            <wire x2="5264" y1="3616" y2="3616" x1="5216" />
        </branch>
        <branch name="XLXN_2707">
            <wire x2="4960" y1="3648" y2="3648" x1="4864" />
        </branch>
        <branch name="XLXN_2708">
            <wire x2="5232" y1="3840" y2="3872" x1="5232" />
            <wire x2="5264" y1="3840" y2="3840" x1="5232" />
        </branch>
        <branch name="XLXN_2732">
            <wire x2="5728" y1="3616" y2="3616" x1="5648" />
        </branch>
        <branch name="PSW0">
            <wire x2="5344" y1="4128" y2="4128" x1="5216" />
        </branch>
        <branch name="LED0">
            <wire x2="6192" y1="4128" y2="4128" x1="6128" />
        </branch>
        <branch name="PSW1">
            <wire x2="5344" y1="4208" y2="4208" x1="5216" />
        </branch>
        <branch name="LED1">
            <wire x2="6192" y1="4208" y2="4208" x1="6128" />
        </branch>
        <branch name="XLXN_2745">
            <wire x2="5664" y1="4128" y2="4128" x1="5568" />
            <wire x2="5904" y1="4128" y2="4128" x1="5664" />
            <wire x2="5728" y1="3680" y2="3680" x1="5664" />
            <wire x2="5664" y1="3680" y2="4128" x1="5664" />
        </branch>
        <branch name="XLXN_2768">
            <wire x2="5680" y1="2928" y2="2928" x1="5552" />
        </branch>
        <branch name="XLXN_2769">
            <wire x2="5696" y1="3152" y2="3152" x1="5552" />
        </branch>
        <branch name="MD_B">
            <wire x2="6000" y1="2928" y2="2928" x1="5904" />
        </branch>
        <branch name="MD_D">
            <wire x2="6000" y1="3152" y2="3152" x1="5920" />
        </branch>
        <branch name="XLXN_2709">
            <wire x2="4640" y1="2928" y2="2928" x1="4592" />
            <wire x2="4592" y1="2928" y2="3152" x1="4592" />
            <wire x2="4640" y1="3152" y2="3152" x1="4592" />
            <wire x2="4592" y1="3152" y2="3376" x1="4592" />
            <wire x2="6016" y1="3376" y2="3376" x1="4592" />
            <wire x2="6016" y1="3376" y2="3648" x1="6016" />
            <wire x2="6016" y1="3648" y2="3648" x1="5984" />
        </branch>
        <branch name="XLXN_2764">
            <wire x2="4944" y1="2896" y2="2896" x1="4896" />
        </branch>
        <branch name="XLXN_2922">
            <wire x2="5296" y1="2896" y2="2896" x1="5168" />
        </branch>
        <branch name="XLXN_2765">
            <wire x2="4944" y1="3120" y2="3120" x1="4896" />
        </branch>
        <branch name="XLXN_2923">
            <wire x2="5296" y1="3120" y2="3120" x1="5168" />
        </branch>
        <text style="fontsize:48;fontname:Arial" x="4472" y="2756">(Decimal Decoder)</text>
        <text style="fontsize:48;fontname:Arial" x="4472" y="2708">Exchange MD1/MD2</text>
        <rect style="linecolor:rgb(0,0,255);linestyle:Dash" width="404" x="4480" y="2792" height="476" />
        <instance x="4640" y="3216" name="XLXI_1559" orien="R0" />
        <instance x="4960" y="3712" name="XLXI_1561" orien="R0" />
        <instance x="4480" y="3904" name="XLXI_1562" orien="R0" />
        <instance x="5168" y="4000" name="XLXI_1563" orien="R0" />
        <instance x="5264" y="3872" name="XLXI_1564" orien="R0" />
        <instance x="5344" y="4160" name="XLXI_233" orien="R0" />
        <instance x="5904" y="4160" name="XLXI_118" orien="R0" />
        <instance x="5344" y="4240" name="XLXI_1065" orien="R0" />
        <instance x="5904" y="4240" name="XLXI_1064" orien="R0" />
        <instance x="5728" y="3744" name="XLXI_1026" orien="R0" />
        <instance x="5296" y="3248" name="XLXI_1596" orien="R0" />
        <rect style="linecolor:rgb(0,0,255);linestyle:Dash" width="348" x="5208" y="2824" height="468" />
        <text style="fontsize:48;fontname:Arial" x="5244" y="2792">Output Inhibit</text>
        <text style="fontsize:48;fontname:Arial" x="5732" y="2848">To a motor driver</text>
        <instance x="5696" y="3184" name="XLXI_845" orien="R0" />
        <instance x="4640" y="2992" name="XLXI_1560" orien="R0" />
        <instance x="5296" y="3024" name="XLXI_1595" orien="R0" />
        <instance x="5680" y="2960" name="XLXI_833" orien="R0" />
        <instance x="4944" y="2928" name="XLXI_1669" orien="R0" />
        <instance x="4944" y="3152" name="XLXI_1670" orien="R0" />
        <branch name="XLXN_2704">
            <wire x2="4272" y1="2096" y2="2096" x1="4128" />
            <wire x2="4272" y1="2096" y2="2864" x1="4272" />
            <wire x2="4544" y1="2864" y2="2864" x1="4272" />
            <wire x2="4544" y1="2864" y2="3088" x1="4544" />
            <wire x2="4640" y1="3088" y2="3088" x1="4544" />
            <wire x2="4640" y1="2864" y2="2864" x1="4544" />
        </branch>
        <branch name="XLXN_3292">
            <wire x2="4192" y1="2288" y2="2288" x1="4128" />
            <wire x2="4192" y1="2288" y2="3648" x1="4192" />
            <wire x2="4416" y1="3648" y2="3648" x1="4192" />
            <wire x2="4480" y1="3648" y2="3648" x1="4416" />
            <wire x2="4944" y1="3472" y2="3472" x1="4416" />
            <wire x2="4944" y1="3472" y2="3584" x1="4944" />
            <wire x2="4960" y1="3584" y2="3584" x1="4944" />
            <wire x2="4416" y1="3472" y2="3648" x1="4416" />
        </branch>
        <text style="fontsize:48;fontname:Arial" x="5988" y="4448">by Susutawari</text>
        <iomarker fontsize="28" x="816" y="1552" name="CLK" orien="R180" />
        <iomarker fontsize="28" x="656" y="3408" name="SW(7:0)" orien="R180" />
        <iomarker fontsize="28" x="672" y="2544" name="PSW2" orien="R180" />
        <iomarker fontsize="28" x="5984" y="1808" name="MD_C" orien="R0" />
        <iomarker fontsize="28" x="5984" y="1584" name="MD_A" orien="R0" />
        <iomarker fontsize="28" x="5216" y="4128" name="PSW0" orien="R180" />
        <iomarker fontsize="28" x="6192" y="4128" name="LED0" orien="R0" />
        <iomarker fontsize="28" x="5216" y="4208" name="PSW1" orien="R180" />
        <iomarker fontsize="28" x="6192" y="4208" name="LED1" orien="R0" />
        <iomarker fontsize="28" x="6000" y="3152" name="MD_D" orien="R0" />
        <iomarker fontsize="28" x="6000" y="2928" name="MD_B" orien="R0" />
        <instance x="3552" y="1872" name="XLXI_1673" orien="R0" />
        <branch name="XLXN_3089">
            <wire x2="3744" y1="2224" y2="2224" x1="3584" />
            <wire x2="3584" y1="2224" y2="2576" x1="3584" />
            <wire x2="3888" y1="2576" y2="2576" x1="3584" />
            <wire x2="3888" y1="2576" y2="2784" x1="3888" />
            <wire x2="3888" y1="2784" y2="2784" x1="3840" />
        </branch>
        <branch name="XLXN_3704">
            <wire x2="3072" y1="2768" y2="2784" x1="3072" />
            <wire x2="3136" y1="2784" y2="2784" x1="3072" />
        </branch>
        <instance x="3008" y="2768" name="XLXI_921" orien="R0" />
        <instance x="3616" y="2816" name="XLXI_1734" orien="R0" />
    </sheet>
</drawing>