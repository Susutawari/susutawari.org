module FDE_VERILOG(CLK, CE, D, Q);

    input  CLK;
    input  CE;
    input  D;
    output Q;

    reg    Q;

    always @(posedge CLK) begin
        if (CE == 1'b1) begin
            Q <= D;
        end
    end

endmodule
