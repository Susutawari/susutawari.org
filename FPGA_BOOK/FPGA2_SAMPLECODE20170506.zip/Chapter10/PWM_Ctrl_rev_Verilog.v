module PWM_Ctrl_rev_Verilog(CLK, SW, PSW0, MD1, MD2, LED0);

   input       CLK;
   input [7:0] SW;
   input       PSW0;
   output      MD1;
   output      MD2;
   output      LED0;

   reg [7:0]   sw_reg_1d;
   reg [7:0]   sw_reg_2d;
   reg [10:0]  pwm_base_reg;
   reg [10:0]  pwm_duty_reg;
   reg         psw0_reg;
   reg [23:0]  psw0_cnt_reg;
   reg         dir;
   reg         pwmout_reg;

   wire        pwmbp;
   wire        pwmout;
   wire        tout;

   /* Switch Input */
   always @(posedge CLK) begin
      sw_reg_1d <= SW;
      sw_reg_2d <= sw_reg_1d;
   end

   /* PWM Base Cycle Generate (48.8kHz@50MHz CLK) */
   always @(posedge CLK) begin
      if (pwmbp == 1'b1) begin
         pwm_base_reg <= 11'h000;
      end
      else begin
         pwm_base_reg <= pwm_base_reg + 1'b1;
      end
   end

   assign pwmbp = pwm_base_reg[10];

   /* PWM Duty Ratio Generate */
   always @(posedge CLK) begin
      if (pwmbp == 1'b1) begin
         pwm_duty_reg <= 11'h000;
      end
      else if (pwmout == 1'b1) begin
         pwm_duty_reg <= pwm_duty_reg + 1'b1;
      end
   end

   assign pwmout = (pwm_duty_reg[10:3] == sw_reg_2d) ? 1'b0 : 1'b1;

   /* To a motor driver */
   always @(posedge CLK) begin
      pwmout_reg <= pwmout;
   end

   /* Stop 0.3s & Toggle switch */
   always @(posedge CLK) begin
      if (tout == 1'b1) begin
         psw0_reg <= 1'b0;
      end
      else if (PSW0 == 1'b1) begin
         psw0_reg <= 1'b1;
      end
   end

   always @(posedge CLK) begin
      if (tout == 1'b1) begin
         psw0_cnt_reg <= 24'h000000;
      end
      else if (psw0_reg == 1'b1) begin
         psw0_cnt_reg <= psw0_cnt_reg + 1'b1;
      end
   end

   assign tout = &psw0_cnt_reg & psw0_reg;

   always @(posedge CLK) begin
      if (tout == 1'b1) begin
         dir <= ~dir;
      end
   end

   assign MD1  = ~(pwmout_reg &  dir) & ~psw0_reg;
   assign MD2  = ~(pwmout_reg & ~dir) & ~psw0_reg;
   assign LED0 = dir;

endmodule
