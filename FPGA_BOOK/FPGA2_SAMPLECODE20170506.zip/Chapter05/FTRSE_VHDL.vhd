library IEEE;
use IEEE.std_logic_1164.all;

entity FTRSE_VHDL is

    port (
        CLK  : in  std_logic;
        R  : in  std_logic;
        S  : in  std_logic;
        T  : in  std_logic;
        CE : in  std_logic;
        Q : out std_logic);

end FTRSE_VHDL;

architecture RTL of FTRSE_VHDL is

    signal Q_reg : std_logic;

begin

    process (CLK)
    begin
        if (CLK'event and CLK = '1') then
            if (R = '1') then
                Q_reg <= '0';
            elsif (S = '1') then
                Q_reg <= '1';
            elsif (CE = '1' and T = '1') then
                Q_reg <= not Q_reg;
            end if;
        end if;
    end process;

    Q <= Q_reg;

end RTL;
